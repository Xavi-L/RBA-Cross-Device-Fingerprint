# HybridGuard ACM Draft — Flattened Overleaf Project

This compact source-only project is the full-prose working draft prepared on 2026-09-03.

- Main document: `hybridguard_draft.tex`
- Bibliography: `references.bib`
- All section and appendix sources have been inlined into the main document.
- The project relies on the `acmart` class and `ACM-Reference-Format` bibliography style provided by Overleaf/TeX Live.
- Generated PDFs and build artifacts are intentionally excluded.

Current claim boundaries: App177 is the current controlled attack-evaluation object; the protocol is `baseline -> attack_active`; transition counts are not attack recall; Browser67/paired244 detection value remains future work; historical ML/LLM material is provisional.
