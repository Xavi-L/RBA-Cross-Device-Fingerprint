# Source aggregate 07

| 模型配置 | 组合 | 材料角色 | 总N | 修改N | 检出T | 漏检F | 修改U | 修改FAILED | 正常N | 报警T | 未报F | 正常U | 正常FAILED | 接入结论 | 原因 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 01 | S0 | 开发接入比较 | 744 | 26 | 13 | 13 | 0 | 0 | 718 | 6 | 649 | 63 | 0 | 保留S0 |  |
| 01 | S0 | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 2 | 242 | 17 | 0 | 保留S0 |  |
| 01 | S0+M | 开发接入比较 | 744 | 26 | 19 | 7 | 0 | 0 | 718 | 8 | 640 | 70 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 01 | S0+M | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 3 | 239 | 19 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 01 | S0+B | 开发接入比较 | 744 | 26 | 16 | 10 | 0 | 0 | 718 | 6 | 642 | 70 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 01 | S0+B | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 2 | 240 | 19 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 01 | S0+W | 开发接入比较 | 744 | 26 | 19 | 7 | 0 | 0 | 718 | 46 | 602 | 70 | 0 | 未通过接入 | NORMAL_ALARM_BUDGET:mtc_discovery；MODEL_DEFINED_COVERAGE:mtc_discovery；CANDIDATE_COVERAGE:W |
| 01 | S0+W | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 24 | 218 | 19 | 0 | 未通过接入 | NORMAL_ALARM_BUDGET:mtc_discovery；MODEL_DEFINED_COVERAGE:mtc_discovery；CANDIDATE_COVERAGE:W |
| 02 | S0 | 开发接入比较 | 744 | 26 | 13 | 13 | 0 | 0 | 718 | 6 | 649 | 63 | 0 | 保留S0 |  |
| 02 | S0 | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 2 | 242 | 17 | 0 | 保留S0 |  |
| 02 | S0+M | 开发接入比较 | 744 | 26 | 19 | 7 | 0 | 0 | 718 | 8 | 640 | 70 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 02 | S0+M | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 3 | 239 | 19 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 02 | S0+B | 开发接入比较 | 744 | 26 | 16 | 10 | 0 | 0 | 718 | 6 | 642 | 70 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 02 | S0+B | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 2 | 240 | 19 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 02 | S0+W | 开发接入比较 | 744 | 26 | 19 | 7 | 0 | 0 | 718 | 46 | 602 | 70 | 0 | 未通过接入 | NORMAL_ALARM_BUDGET:mtc_discovery；MODEL_DEFINED_COVERAGE:mtc_discovery；CANDIDATE_COVERAGE:W |
| 02 | S0+W | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 24 | 218 | 19 | 0 | 未通过接入 | NORMAL_ALARM_BUDGET:mtc_discovery；MODEL_DEFINED_COVERAGE:mtc_discovery；CANDIDATE_COVERAGE:W |
| 03 | S0 | 开发接入比较 | 744 | 26 | 13 | 13 | 0 | 0 | 718 | 0 | 655 | 63 | 0 | 保留S0 |  |
| 03 | S0 | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 0 | 244 | 17 | 0 | 保留S0 |  |
| 03 | S0+M | 开发接入比较 | 744 | 26 | 19 | 7 | 0 | 0 | 718 | 2 | 646 | 70 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 03 | S0+M | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 1 | 241 | 19 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 03 | S0+B | 开发接入比较 | 744 | 26 | 16 | 10 | 0 | 0 | 718 | 0 | 648 | 70 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 03 | S0+B | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 0 | 242 | 19 | 0 | 未通过接入 | MODEL_DEFINED_COVERAGE:mtc_discovery |
| 03 | S0+W | 开发接入比较 | 744 | 26 | 19 | 7 | 0 | 0 | 718 | 40 | 608 | 70 | 0 | 未通过接入 | NORMAL_ALARM_BUDGET:mtc_discovery；MODEL_DEFINED_COVERAGE:mtc_discovery；CANDIDATE_COVERAGE:W |
| 03 | S0+W | 历史正常回放 | 261 | 0 | 0 | 0 | 0 | 0 | 261 | 22 | 220 | 19 | 0 | 未通过接入 | NORMAL_ALARM_BUDGET:mtc_discovery；MODEL_DEFINED_COVERAGE:mtc_discovery；CANDIDATE_COVERAGE:W |
