# Appendix A. Configuration and Reproducibility Details

## A.1 Saved Model Identities

App configurations 01, 02, and 03 hold out emulator API 29, 30, and 36, respectively. APP_FULL denotes the retained B_REL_TZ models, called Integrated App in the main text. A_NO_MTC_CAP, A_APP_WEB_ONLY, A_NO_MEMORY_REL, and A_NO_TIMEZONE_REL are refitted alternatives. APP_TREE uses saved FITTED outputs; rule models use saved RETENTION outputs. PAIRED_BASE is the frozen App detector plus C1. These names do not add Host geometry to Integrated App.

The candidate-state tree uses scikit-learn 1.7.2, splitter=best, random_state=20261006, no class-weight override, and a positive-class probability threshold of 0.5. Its admitted pools contain 63, 63, and 54 atoms, each encoded by three state indicators; these are smaller than the pre-admission pools. Fifteen positions in each controlled held-out set and 73/891 MTC records have an unknown candidate. A fitted path need not use that candidate, so binary predictions do not imply complete observation.

## A.2 Candidate Admission and Extension Choice

Threshold expansion uses training-only quantiles 0.25, 0.5, and 0.75. Candidate support requires at least three complete true/false triplets and at least two triggered modification triplets in at least one bundle/environment, alongside normal assessability. For Browser extension, feasible choices among none, C1, C2, and C1+C2 are ranked by the equal mean detection ratio across App timezone, App language, Browser timezone, and Browser language. Ties prefer fewer additions and then a fixed set order. This ranking is part of development-side selection.

The fixed timezone comparator triggers above −480 minutes; the old Web-height comparator triggers above 710 CSS pixels. Native timezone uses effective offsets under the fixed implementation database. Geometry follows Section 3.3. C1 requires both status and quality markers, accepts finite numeric offsets including zero and minus one, and applies no timestamp gate.

## A.3 Full Tables and Statistical Units

The original research archive's tables S01--S09 retain aggregate results, including adverse outcomes. Chinese source field names preserve the input schema; main-text tables use English labels. S02 contains 14 recipes × 6 methods = 84 rows. Its five count-pattern groups have sizes 1, 1, 2, 8, and 2, with nine effective modifications per recipe. Weighted sums reproduce 105, 108, 96, 96, 105, and 72 detections. App language-list edits are distinct from the paired study's language operations.

S07 reports resource-admission comparisons on 26 modified and 718 normal development positions, plus a separate replay of 261 historical normals. S0 is the frozen Integrated App + C1 baseline. M adds a Native-to-Browser memory-envelope check, W tests inequality between App-Web and Browser memory reports, and B tests Browser memory above 8 GiB. S0 detects 13/26; S0+M and S0+W detect 19/26; S0+B detects 16/26. These additions fail coverage and/or normal-alarm admission criteria, so they do not replace the retained App-plus-C1 results on 14 paired modifications.

S08 reports a four-view development diagnostic. The four-view diagnostic uses language and timezone measurements: App only, Browser only, their concatenation, and the concatenation augmented by C1/C2 states. P0 trains on the 630 discovery normals and both paired batches. P1 and P2 withhold the 18-position pilot and 42-position matched batch, respectively, while training on the discovery normals and the other batch. The relation-augmented P0 fit yields 14/14 detections and 0/46 normal alarms; under P2, the relation-augmented view yields 4/8 and 6/34. These settings are not independent replications. S09 times cached_from_adapted execution in batches of 60 over ten rounds. Its microseconds-per-position medians and batch-amortized p95 values exclude acquisition and communication; they are neither per-request latency percentiles nor end-to-end costs.

## A.4 Public Dataset and Verification Scope

The Cross-View Consistency Dataset v1.0 contains 378 controlled App, 72 memory, 36 timezone, 72 Host-geometry, 60 linked-Browser, and 891 historical MTC observations. The first four groups form 558 App177 records; the last two form 951 Paired244 records. Of the 618 experimental observations, 170 are labeled modified, 442 normal_control, and six no_effect. Labels are reconciled against saved collection and intervention evidence, separately from saved detector outputs. The six no-effect memory operations remain outside that study's 18-modification and 48-normal denominators. MTC records remain unlabeled; their 630/144/117 historical partition retains its development exposure.

Four JSONL files provide measurements, metadata, annotations, and relationships, joined by random release identifiers. They retain 206 experiment triplets and 951 App--Browser endpoint associations, without establishing independent physical-device identities. The field catalogue documents 177 App slots and 67 additional Browser slots. Original field structure is complete for 1,506 records; three MTC records each lack five original fields. Collection availability, original absence, and privacy suppression are represented separately. Recorded geometry supplements accompany 72 observations.

The release includes a dataset card, schema, field catalogue, statistics, manifest, and standalone Python tools. Running `python3 validate.py --root .` checks schema, joins, label consistency, missingness, relationships, and descriptive statistics; `python3 load_example.py --data .` demonstrates loading. Data and designated documentation are licensed under CC BY 4.0; this grant excludes the two scripts, whose software-license status is unspecified. Suppressed identifying or decision-relevant values, omitted raw logs, and the absence of the full detector implementation limit reproduction to the released projection and its statistics. Saved detector outcomes remain annotations rather than newly computed predictions.

Separately, manuscript checks reconcile saved state partitions, recipe-level counts, experiment identifiers, and file hashes. Release-label reconciliation uses archived evidence rather than an independent experiment. Tests of decision states and binding failures in the research implementation are distinct from the reported benchmark outcomes.

## A.5 Implementation and Comparator Provenance

The paths below identify the original research archive, which is separate from the public dataset release. It records the 50 base templates and three relations in `deliverables/app177_core_ablation_v1/CANDIDATES.json`, with dependencies in `CANDIDATE_DEPENDENCIES.md`. Final B_REL_TZ models are saved under `deliverables/timezone_relation_validation_v1/trials/B_REL_TZ__WEBGL1-LOEO-v1-{01,02,03}__RETENTION/model.json`. All three select Native--Web timezone and memory relations, MIME type count above zero, the first-language relation (`RSR-LANG-FIRST-v1`), and the registered UA/platform condition (`CAT:NW-006`). Configurations 01/02 also select Web inner height above 710 CSS pixels; configuration 03 does not. The resulting models have 6/6/5 clauses and complexity 12/12/10.

The active selector, `hybridguard_agent/research/rule_learning_v2/semantic_selection.py`, ranks feasible retention proposals by higher macro-averaged detection gain, higher semantic-coverage gain, fewer controlled-normal alarms, higher minimum phase coverage, lower complexity, higher semantic quality, and finally a structural key. The six saved B_REL_TZ fits terminate through their heuristic stopping criteria, with recorded elapsed times of 0.19--0.48 seconds. The 60-second deadline is applied to each fit and is not their recorded stopping reason.

Record-level outputs are retained in `deliverables/timezone_relation_validation_v1/predictions.jsonl.gz`, `deliverables/app177_core_ablation_v1/results/{full_predictions,predictions}.jsonl.gz`, and `deliverables/cross_endpoint_constrained_extension_v1/results/predictions.jsonl`. These archives support inspection beyond the aggregate tables; saved outputs and independently reproduced results remain distinct forms of evidence.

Comparator provenance differs across studies. The 8 GiB condition was fixed in the memory study's `SETTINGS.json` before the 72-position collection that yielded 18 effective modifications and 48 normal positions; comparisons on the older controlled and MTC records were retrospective. The legacy 710 CSS-pixel height condition appears in the geometry study's `CONDITIONS_FROZEN.json`, fixed before the formal 72-position batch and after six engineering smoke observations. The −480-minute comparator is the legacy absolute-offset condition from the saved B_REL models; old and new model identities were frozen before the 36-position timezone collection. These are controlled mechanism studies conducted during development. The memory envelope and geometry tolerance remain engineering hypotheses within their stated domains. Appendix A.6 adds a post hoc sensitivity analysis of the Host geometry tolerance; memory-envelope sensitivity remains unexamined.

## A.6 Host Geometry Tolerance and Post Hoc Sensitivity

The standalone Host geometry check uses the frozen tolerance:

$$\epsilon(P,H_{\mathrm{view}})
=2+4\cdot 2^{-23}\max(|P|,|H_{\mathrm{view}}|,1)
\quad\text{pixels}.$$

The constant 2 allocates one pixel to each of two layout edges as a study-specific quantization assumption. The factor $2^{-23}$ is the float32 precision scale, and 4 is a fixed coefficient for the numerical margin. This reference scale sets the budget; the saved evaluator computes the comparison using Python `float` arithmetic. The archived rationale leaves an operation-level error derivation for the actual rendering chain open. Establishing a common error bound across WebView implementations requires further implementation-specific analysis. The specification was frozen during development after six engineering-smoke observations and before the formal v15 batch.

We perform a *post hoc sensitivity analysis* using only the 72 formal v15 observations saved in `deliverables/screen_geometry_observation_v1/predictions.jsonl.gz`. The 66 normal records satisfy `normal_basis.supported`; the six effective interventions satisfy `observable_intervention`. These are repeated observations from three emulator environments. Keeping the saved applicability, U/FAILED states, and subset labels fixed, we use each record's current Web operands and measured Host dimensions. We preserve the implementation's multiplication order: first DPR times `visualViewport.scale`, then the CSS dimension times that product. Each axis uses a strict $>$ comparison, and axis outcomes are combined by the original OR rule. With $M=\max(|P|,|H_{\mathrm{view}}|,1)$, Table 7 reports the outcomes.

**Table 7. Post hoc Host geometry tolerance sensitivity on 66 normal and six effective-intervention observations.**

| Tolerance (pixels) | Normal alarms | Intervention detections |
| --- | ---: | ---: |
| $2$ | 36/66 | 6/6 |
| $2+1\cdot2^{-23}M$ | 0/66 | 6/6 |
| $2+2\cdot2^{-23}M$ | 0/66 | 6/6 |
| $2+4\cdot2^{-23}M$ (original) | 0/66 | 6/6 |
| $2+8\cdot2^{-23}M$ | 0/66 | 6/6 |
| $3$ | 0/66 | 6/6 |

For each record, take the maximum of $P-H_{\mathrm{view}}$ over width and height. Its largest normal value is approximately $2.000038$ pixels; effective interventions span $475.381$--$664.381$ pixels. Removing the relative term therefore changes decisions for normal observations near the 2-pixel boundary. Coefficients 1, 2, 4, and 8 yield identical decisions on all 72 records, leaving the choice among these coefficients unresolved by this batch. Assessing parameter optimality and performance against small near-boundary interventions requires additional observations. The fixed 3-pixel row serves as a sensitivity comparator; the original coefficient 4 remains the frozen setting. This retrospective analysis follows the original parameter selection, and independent validation of any revised tolerance requires fresh observations.
