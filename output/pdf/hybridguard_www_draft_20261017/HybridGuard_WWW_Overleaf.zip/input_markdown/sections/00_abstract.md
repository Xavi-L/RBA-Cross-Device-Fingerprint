# HybridGuard: Cross-Layer Consistency as Integrity Evidence for Android Web Environments

Anonymous Author(s)

## Abstract

Web services use browser-visible environment reports to recognize clients and inform security decisions, yet reports can be modified without corresponding device changes. In Android hybrid Web applications, Android Native, WebView Host, and App Web provide complementary observations of the same environment. Their semantic relationships offer potential integrity evidence: an individually plausible Web report may be incompatible with its system or container context.

HybridGuard associates observations from the same hybrid Web execution and checks their semantic compatibility, accounting for unavailable evidence and legitimate cross-API differences. We collect these observations and use controlled fingerprint manipulations and separate fixed-check comparisons to examine the effectiveness and limits of cross-layer references.

Across 14 controlled manipulation configurations, HybridGuard’s App detector detects 105/126 effective modifications (83.3%), with no alarms on 252 controlled normal records. A Native memory reference detects 18/18 modifications versus 6/18 for a global Web-only threshold, both with 0/48 normal alarms, showing the additional information supplied by device-specific context. A Native timezone reference and an absolute Web condition each detect 6/6 modifications, with 0/30 and 6/30 normal alarms, respectively; those six alarms arise from legitimate system timezone changes. In a separate WebView Host geometry study, a Host reference and a fixed Web-height threshold each detect 6/6 modifications, with 0/66 and 6/66 normal alarms, respectively; the threshold flags legitimate layout changes. These findings support cross-layer consistency as useful integrity evidence when an observable, semantically related reference remains informative beyond the manipulated report. Neither Native nor Host is a root of trust, and consistency neither proves authenticity nor guarantees detection of coordinated cross-surface manipulation.

**CCS Concepts:** Security and privacy → Web application security; Intrusion/anomaly detection and malware mitigation.

**Keywords:** Android WebView; environment report integrity; cross-layer consistency; fingerprint manipulation; semantic references.
