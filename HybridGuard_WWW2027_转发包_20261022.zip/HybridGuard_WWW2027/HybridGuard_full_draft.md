# HybridGuard: Cross-Layer Consistency as Integrity Evidence for Android Web Environments

Anonymous Author(s)

## Abstract

Browser-visible environment reports can inform security decisions but can be altered independently of the underlying device. We study whether associated Android Native and WebView Host observations provide conditional integrity evidence for App Web reports. HybridGuard associates observations with an execution, evaluates semantic relations under explicit applicability conditions, and distinguishes true, false, unknown, and failure outcomes. On 126 effective modifications from 14 known recipes in three emulated environments, the integrated App detector identifies 105 modifications, compared with 96 for a separately reconstructed Web-only detector; both raise no alarms on 252 controlled-normal record positions. A refit no-memory alternative also identifies 96 positions; all nine differences occur in the CPU-plus-memory recipe. These refitted comparisons establish component associations within the protocol, not frozen-model causal effects. Exploratory fixed-check comparisons illustrate the mechanisms: the Native memory envelope detects 18/18 tested modifications versus 6/18 for a global threshold, while Native timezone and standalone Host geometry each avoid six normal alarms raised by their absolute comparators. Removing the historical-normal alarm cap gains three controlled detections but alerts on every historical evaluation record. On development-used paired data, a Browser-timezone relation adds five detections while increasing historical unknown outcomes from 14/261 to 17/261 per model. These controlled findings show how contextual references can distinguish selected report edits from legitimate variation, while exposing the accompanying alarm and availability costs. They do not establish attestation or unseen-attack generalization.

**CCS Concepts:** Security and privacy → Web application security; Intrusion/anomaly detection and malware mitigation.

**Keywords:** Android WebView; environment report integrity; cross-layer consistency; fingerprint manipulation; semantic references.

# 1 Introduction

Web security decisions often depend on what a client reports about its execution environment. Browser-visible properties can help recognize returning clients or augment authentication, but their usefulness depends on more than distinctiveness: a reported value can be plausible and still be fabricated [1,2]. Targeted browser spoofing demonstrates that an adversary can imitate fingerprint attributes through browser modifications [3]. The resulting Web challenge is to assess the integrity of environment reports without treating those reports themselves as an authenticated description of the device.

Android hybrid applications provide a concrete setting for this problem. JavaScript runs inside a WebView whose host and underlying Android environment expose partially overlapping observations [11]. A Web memory value can fit a global range yet exceed a device-specific envelope. A normal timezone change can alter both system and Web observations while preserving their relationship. Container resizing can change webpage geometry without manipulation. These cases suggest that useful evidence comes from interpreting a report against relevant context, rather than simply collecting more attributes or flagging every difference.

Consistency is already an established fingerprinting technique [4,6,7]. The question we address is more specific: **when do Native and Host references make a Web report distinguishable from legitimate environmental variation, and what evidence costs accompany that distinction?** The references are not trusted roots. They are measurements with their own availability, timing, and semantic limitations. A useful detector must therefore distinguish a violation from an unassessable relation and must account for alarms on legitimate observations.

HybridGuard associates Native, WebView Host, and App Web observations from the same execution, instantiates applicable semantic checks, and constructs a compact detector under normal-alarm and coverage constraints. The integrated App detector uses within-view conditions together with Native memory and timezone relations. Host geometry is implemented and evaluated as a separate specialist. An optional external Browser contributes a linked timezone comparison; it is a separate execution context, not another component of the same WebView.

The controlled App benchmark contains 126 effective modifications and 252 normal record positions. The integrated App detector identifies 105 modifications, compared with 96 for a separately reconstructed Web-only detector, with no controlled-normal alarms for either. The refit no-memory alternative also identifies 96; all nine differences occur in the CPU-plus-memory recipe. Removing Native timezone does not change the aggregate total. Most coverage is therefore shared with within-view checks, and the component comparison associates the remaining difference with memory under the reconstruction protocol. Fixed-check comparisons isolate the role of references, while historical normal records reveal costs hidden by the controlled benchmark. In particular, a three-detection gain without the normal-alarm cap coincides with alarms on every historical evaluation record. Additional Browser evidence likewise brings a targeted benefit and more unknown outputs.

The contribution is a controlled study of contextual references for report integrity, evaluated through saved checker outputs. It has three parts:

**Conditional evidence semantics.** We specify an observation and decision model that associates complementary Android observations with an execution and evaluates semantic constraints with explicit applicability, unknown, and failure states. It separates an assessable predicate violation from absent evidence.

**Exploratory mechanism evidence.** Bounded fixed-check comparisons illustrate how device-specific bounds, legitimate co-change, and container context can distinguish the tested reports from normal variation. Native memory and timezone are integrated; Host geometry is evaluated separately.

**Alarm and availability trade-offs.** Reconstructed detector alternatives and a linked-Browser extension show why detection counts must be considered together with normal alarms and definite-output coverage. These results concern report integrity on the studied materials, not identity uniqueness or authentication outcomes.

# 2 Background, Prior Work, and Scope

## 2.1 Fingerprint Consistency and the Remaining Question

Fingerprinting research already uses relationships and behavioral checks to scrutinize reported attributes. FP-Scanner detects inconsistencies introduced by fingerprint countermeasures, including discrepancies across JavaScript and HTTP reports [4]. Picasso compares canvas challenge responses against device-class expectations [5]. FP-Inconsistent studies spatial and temporal inconsistencies in evasive bot traffic [6]. BrowserFM represents dependencies among fingerprints, system characteristics, and browser configurations [7]. Thus, neither inconsistency detection nor structured dependency modeling is new in itself.

WebView research also observes both sides of the application–Web boundary. WVProfiler instruments Android WebViews to study fingerprint exposure [8]; Tracking Without Borders analyzes Java/Kotlin, JavaScript, and runtime behavior to investigate tracking [9]; Cross-Boundary Mobile Tracking studies Java-to-JavaScript information diffusion [10]. Table 1 locates our study among these approaches. Our focus is the compatibility of a current Web report with associated Android device and container measurements, tested against both controlled report edits and legitimate environmental changes. The technical focus is the combination of associated Native or Host references for a current App Web record, predicate-specific applicability and evidence states, and joint accounting of modification coverage, normal alarms, and definite outputs. The table maps this scope rather than establishing comparative performance.

**Table 1. Closely related research and the evidence it examines.** The comparison identifies the study focus rather than claiming absent capabilities or empirical superiority.

| Work | Evidence examined | Research focus | Focus of the present study |
| --- | --- | --- | --- |
| FP-Scanner [4] | Browser attributes; JavaScript/HTTP discrepancies | Countermeasure-induced inconsistencies | Associated Native and Host references |
| Picasso [5] | Canvas challenge responses | Claimed device-class checking | Current-record semantic compatibility |
| FP-Inconsistent [6] | Within-request and temporal inconsistencies | Evasive bot traffic | Controlled edits versus normal changes |
| BrowserFM [7] | Fingerprint/configuration dependencies | Configuration modeling and analysis | Applicability and evidence-availability costs |
| WebView studies [8–10] | App, JavaScript, and runtime observations | Exposure and cross-boundary tracking | Report-integrity assessment |
| HybridGuard | Native, Host, App Web; optional Browser | Contextual references under explicit domains | Detection, normal alarms, and unknown outcomes |


## 2.2 Observation Surfaces and Conditional Compatibility

Let E denote the relevant execution state and container context. The associated observation x = (N(E), H(E), W(E)) contains Native measurements of the system and hardware, WebView Host context, and App Web reports. The App schema contains 177 catalogued fields: 84 Native, 26 Host, and 67 App Web fields. The optional Browser schema contains 67 fields from a separate Web execution; a valid association yields a 244-field paired schema. These are schema-field counts, not independent signals or the number of inputs used by each selected detector.

![Figure 1. Associated observation surfaces and integration boundaries.](figures/figure_01_surfaces.png)

**Figure 1.** Native–App Web memory and timezone relations are integrated. Host geometry is a separate study. The optional Browser comparison links separate executions. Field counts describe the catalogued schemas; selected checks use a subset. Connectors denote comparisons, not mutual authentication or trusted communication.

A semantic relation C_j constrains a relevant subset of observations within an applicability domain. Local modification can replace W(E) with W′(E) while leaving a distinguishing reference unchanged. A relation violation then supplies evidence of incompatibility. Legitimate changes can instead move related observations together. Neither case requires equality between all fields: different APIs may expose different units, precision, or abstractions. E is explanatory notation, not ground truth supplied to the detector. We call an observed violation conditional report-integrity evidence: within a predicate's stated applicability domain, the jointly observed values violate its declared constraint. This evidence does not identify an altered operand or establish the truth of an individual observation. A trigger becomes a detection in the evaluation only when it occurs on a known effective modification.

## 2.3 Adversary and Claim Boundary

The evaluated attacker surface is the report exposed to the Web application. Controlled browser overrides or emulation alter selected resource, browser, locale, display, and graphics reports while the compared reference can remain unchanged. The intended setting is a cooperating Android application that can obtain Native and Host measurements alongside its embedded webpage; an ordinary remote website cannot obtain these measurements from an arbitrary client without such integration. A measured effect at the target surface is required for an effective modification. The detector receives the current observation, not operation labels, an earlier baseline, or a recovery record. Native and Host measurements can also be manipulated; their position outside a local Web override does not establish administrative or statistical independence.

Our target is evidence about report integrity. An alert does not establish malicious intent, account takeover, or attacker identity, and no alert does not certify authenticity. An adversary can preserve the selected relations, including through coordinated changes. Resistance to collector compromise, backend compromise, or adaptive evasion is not established. This scope separates the use of observations for integrity checking from their use for tracking or device re-identification.

# 3 HybridGuard Design

## 3.1 Provenance-Bound Collection

Comparisons require observations tied to the execution they describe. The HybridGuard specification requires field values, collection states, and association context to be preserved under measurement contracts, with source records and receipts for tracing and binding checks. Missing external Browser collection retains an App-only record rather than creating a synthetic Browser vector. Association does not imply atomic sampling or hardware attestation.

Measurement context is part of applicability. In the geometry study, Host snapshots immediately before and after the Web snapshot support a stability check within one collection. These snapshots are not intervention-before and recovery-after records. Experimental phases and restoration records are used to assess the experiment, not to predict the current record. Figure 2 separates this online path from offline detector construction.

![Figure 2. State-aware evaluation and offline construction.](figures/figure_02_pipeline.png)

**Figure 2.** Selected checks evaluate current, associated observations. An empty selection has its own status. Relevant execution or binding failures take precedence; otherwise any true condition alerts, all false conditions yield no alert, and unresolved cases yield unknown. Offline fitting supplies a frozen model. The gray dash in the schematic denotes U (unknown); the four condition states are T, F, U, and FAILED.

## 3.2 Evidence States and Decision Semantics

Each condition records its operands, source requirements, semantic interpretation, applicability, and trigger. Its output is r_j(x) ∈ {T, F, U, FAILED}. T means an applicable, assessable predicate triggers an alert; F means that this predicate does not trigger, without certifying the report; U means required evidence is missing, insufficient, or outside the domain. FAILED records a relevant execution or association failure. EMPTY_MODEL denotes an empty selection. None of these states is an identity label.

For a nonempty selected set, required-input failures yield FAILED before any trigger is considered. In their absence, any T produces an alert; all F produces a definite no-alert result; every remaining combination produces U. Thus, T can coexist with another condition's U, but cannot override FAILED. Missing unselected fields do not independently fail a detector. Preserving U prevents an unavailable reference from silently becoming evidence of normality.

## 3.3 Semantic References

**Native memory envelope.** For observed, finite, positive memory measurements in GiB from the same bound App record, with m_native ≥ 0.25, the condition is

$$r_{mem}(x)=T \iff m_{web}>2^{\lceil\log_2 m_{native}\rceil}.$$

The Device Memory API draft describes approximate reporting with implementation-defined bounds [13]; that discontinued draft is historical API context, not a guarantee of runtime behavior. The power-of-two envelope is an engineering hypothesis that accommodates coarse reporting and permits lower Web exposure; it is not a guaranteed Android or Web platform invariant. It detects upward violations, not every modification. Within-envelope or coordinated reports can remain compatible. Unusable operands yield U; binding failures yield FAILED. The fixed Web-only comparator tests m_web > 8 GiB. A schematic example is Native memory of 4 GiB and a Web report of 8 GiB: the global check remains false, while the device-specific envelope is violated. The example illustrates the predicate rather than adding an experimental record.

**Native timezone reference.** The Native IANA zone and current collection interval determine the effective UTC offset using the implementation's fixed timezone database, 2026c. Writing o_native(t) for local-minus-UTC minutes at the applicable collection time and o_web for Web getTimezoneOffset, the trigger is o_web ≠ −o_native(t). This conversion follows the Web API's UTC-minus-local sign [14]. Supported fixed-offset identifiers can be checked without a date when consistent with the observed Native standard offset. Different zone names with the same effective offset are compatible. Missing reliable intervals for time-dependent zones, ambiguous transitions, or unusable observations yield U; database or association failures follow the failure policy. Zero and minus one are valid offsets, not missing-value sentinels.

**Host geometry reference (standalone).** The Web interface exposes visual-viewport dimensions in CSS pixels and a separate scale factor [15]. For each axis, P is CSS visual-viewport size multiplied by device-pixel ratio and viewport scale; H_view is the Host View size minus its own padding. The trigger is

$$P>H_{view}+\epsilon,\quad \epsilon=2+4\cdot2^{-23}\max(|P|,|H_{view}|,1)\ \text{pixels}.$$

The condition requires bound snapshots, independently assessed Host stability, finite positive dimensions and scale, an attached visible View, zero padding, and an identity View transform. Outside-domain observations yield U. Stability does not require Host–Web agreement, so a stable contradiction remains assessable. The tolerance is an engineering choice, not a platform guarantee. This condition is outside Integrated App and its candidate pool.

## 3.4 Constrained Construction and Retention

The App pool contains 50 base templates and three fixed relations: Native memory, Native timezone, and same-Web viewport. A template defines a condition over available fields; an atom is its encoded, threshold-instantiated predicate. A literal selects an admitted polarity, and each singleton clause contains one literal. The detector ORs the selected clauses using the state semantics in Section 3.2. Training-only numeric encoding and threshold expansion produce 65/65/56 atoms before admission in configurations 01/02/03. Candidate polarity and assessability are checked before selection. Historical evaluation records do not provide threshold quantiles.

For a set S of singleton-OR clauses, the sparse stage uses

$$J(S)=\frac{1}{14}\sum_{k=1}^{14}d_k(S)-0.005\,C(S).$$

Here k indexes the 14 manipulation recipes, not the three fitted model configurations. For each recipe, d_k averages whole-detector detections over effective modifications within a training environment, then equally across its two training environments. Each environment contributes three effective modification positions per recipe. C(S) counts clauses plus literal occurrences. Thus, with singleton clauses, a selected literal contributes two units of complexity. Greedy improving additions, the best feasible prefix, and backward pruning form a heuristic, not a global optimizer. Limits are eight clauses, complexity 16, two conditions per registered family, and no opposite polarities for one atom. Controlled-normal and historical training-normal alarm budgets are 8/168 and 31/630. Candidate assessability is the fraction of records on which the candidate yields T or F; definite-output coverage is the fraction on which the whole detector yields T or F. Historical candidate assessability and final coverage must each reach 90%; controlled coverage must reach 80% in each pre, modified, and post phase. Fits allow no execution failures and have a 60-second deadline.

Retention starts from each configuration's own sparse solution and preserves existing training detections. Additions extend semantic coverage; same-group swaps use registered higher-quality alternatives and forbid new controlled-normal alarms or lost definite controlled outputs. Proposals must remain feasible. Retention is not further maximization of J. Evaluation uses each saved retention model without selecting a different stage for individual result cells.

## 3.5 Optional Linked Browser

Integrated App + C1 adds a timezone comparison between linked App Web and Browser records. C1 requires observed field status, observed-value quality, and finite numeric non-Boolean operands. It alerts on unequal offsets under the same Web sign convention. Missing operands yield U; invalid association yields FAILED. C1 has no timestamp gate and does not inherit the Native timezone relation's interval handling.

Extension construction considers no addition, C1, language condition C2, and C1+C2 on the frozen App base. Normal-alarm budgets are 31/630, 0/12, and 1/34 for historical training, pilot, and matched normals, with 90% definite outputs per normal group and 90% historical candidate assessability. C2 alarms on two matched normal preference changes; C1+C2 also provides only 566/630 definite historical training outputs. The retained C1 extension is therefore a constrained choice on development-used material, not a new jointly trained classifier or an automatic fallback.

# 4 Evaluation Protocol

## 4.1 Questions and Materials

We ask four questions: how much controlled App manipulation is detected (RQ1); what semantic references contribute (RQ2); what normal-alarm and availability costs arise (RQ3); and whether a linked Browser adds evidence (RQ4). All rates summarize coverage of recorded benchmark positions, not independent devices or unseen attacks. Table 2 fixes the denominators. The studies have different roles, development histories, and potentially overlapping sources or analysis ranges; we do not sum them into a new sample population or accuracy estimate.

**Table 2. Evaluation materials and their roles.** Counts are record positions, not independent physical devices.

| Material | Effective modifications | Normal records | Evaluation role |
| --- | --- | --- | --- |
| Controlled App | 126 | 252 | 14 configurations × 3 repetitions × 3 environments; disjoint held-out positions |
| MTC discovery | — | 630 | Training-side constraints and tree training |
| MTC historical development | — | 144 | Historical evaluation with development exposure |
| MTC historically reserved | — | 117 | Historical evaluation; not a newly blinded cohort |
| Memory specialist | 18 | 48 | Fixed checks; 6 no-effect operations excluded |
| Timezone specialist | 6 | 30 | Includes 6 normal system changes |
| Geometry specialist | 6 | 66 | Includes 6 normal layout changes; not integrated |
| Paired App–Browser | 14 | 46 | 60 development-used positions: pilot 18 + matched 42 |

The controlled App material covers API 29, 30, and 36 emulator environments with SwiftShader. Fourteen configurations, three repetitions, and three environments yield 126 effective modifications. Each admitted run contributes normal pre- and confirmed post-records, yielding 252 normals. Model identifiers 01, 02, and 03 hold out API 29, 30, and 36, respectively; these three fitted models are distinct from the 14 manipulation recipes. Each uses 84 modified and 168 normal training records, with 42 modified and 84 normal held-out records. The disjoint held-out positions are aggregated once. Development exposure to these environments and recipes prevents interpreting the split as unseen-tool or physical-device attack generalization.

A mobile test-cloud (MTC) representative corresponds to a combination of manufacturer, model, and Android release. They are not 891 independent devices. The 630-record discovery group informs constraints and tree training; the 144- and 117-record historical groups remain separately reported and have development-use history. “Normal” means absence of the study-defined target manipulation, not certified authenticity or absence of debugging and automation.

## 4.2 Compared Methods

Integrated App combines within-view and cross-view checks. Four alternatives rebuild their own sparse and retention stages: removing the MTC alarm cap, retaining only App Web information, removing memory, and removing timezone. Removing the cap relaxes only that alarm budget; other MTC assessability and coverage constraints remain. Web-only changes both available information and constructible relations, so it is not a pure single-factor causal intervention.

The App tree uses the same fold-specific admitted candidate-state representation, encoded by T/F/U indicators. It has depth three, minimum leaf size two, and Gini splitting. Training assigns half the weight to modifications, one quarter to controlled normals, and one quarter to MTC normals; modification weight is balanced across configurations. This is a fixed representation/capacity comparator, not an exhaustive evaluation of machine learning on raw fields. The tree uses saved fitted outputs; rule models use saved retention outputs. Specialist checks and Integrated App + C1 retain their separate identities.

## 4.3 Measures and Aggregate Reconciliation

A detection is T on an effective modification; a normal alarm is T on a normal record. We separately retain F, U, FAILED, and EMPTY_MODEL. Unknowns remain in their denominators and count as neither definite normal decisions nor successful detections. Repeated configurations do not create additional records; equal counts do not prove equal record-level predictions. We report descriptive counts without significance tests or population estimates.

The artifact contains aggregate state counts, recipe identifiers, and mappings to saved experiment summaries. Arithmetic checks verify state partitions and agreement between per-recipe counts and reported totals. These checks do not independently establish the correctness of labels or collection bindings. Raw payloads, collection logs, pairing tickets, and the complete detector implementation are not part of this artifact, limiting independent reconstruction of per-record effects and temporal associations.

# 5 Results

## 5.1 RQ1: Detection and Component Comparisons

Integrated App covers 105 of 126 controlled modification positions, with 0/252 controlled-normal alarms (Table 3). The reconstructed Web-only and no-memory alternatives each cover 96/126; all nine differences occur in the CPU-plus-memory recipe. This is a component association under the reconstruction protocol, not a causal effect of deleting a condition from a frozen model. No-timezone preserves 105/126 because an absolute-offset condition substitutes on this benchmark. Removing the MTC cap gains three screen detections; Section 5.3 examines the normal-data cost. The App tree detects 72/126 under its fixed representation and capacity.

**Table 3. Controlled benchmark-position outcomes.** All methods have zero U, FAILED, and EMPTY_MODEL counts on these held-out positions. Ablations are separately reconstructed models.

| Method | Detected / modified | Detection (%) | Missed | Normal alarms |
| --- | --- | --- | --- | --- |
| Integrated App | 105/126 | 83.3 | 21 | 0/252 |
| No MTC cap | 108/126 | 85.7 | 18 | 0/252 |
| Web-only | 96/126 | 76.2 | 30 | 0/252 |
| No memory | 96/126 | 76.2 | 30 | 0/252 |
| No timezone | 105/126 | 83.3 | 21 | 0/252 |
| App tree | 72/126 | 57.1 | 54 | 0/252 |

These percentages describe positions in a fixed factorial benchmark. The 252 controlled-normal positions comprise two correlated positions from each of 126 manipulation runs. Repetitions within an emulator environment do not create independent devices; the counts are descriptive summaries, not population estimates.

At recipe level, Integrated App detects 9/9 CPU-plus-memory modifications and 6/9 screen modifications. It detects all nine instances of each timezone-only and plugins/MIME configuration, as well as all eight shared-detection configurations: Playwright, Puppeteer, CDP multi-field, and Stealth presets; platform-only, UA-only, UA-plus-platform, and language-list modifications. All six methods miss 9/9 webdriver-only and 9/9 WebGL-identifier modifications. Historical raw WebGL unavailability and lost webdriver-false semantics limit admission of the corresponding candidates. The saved analysis attributes these misses to representation and admission limitations; the aggregate counts alone do not establish intrinsic undetectability. Appendix A preserves the recipe grouping and supplemental tables contain all 84 configuration-by-method cells.

## 5.2 RQ2: What References Contribute

Exploratory fixed checks illustrate three complementary mechanisms (Figure 3; Table 4). These fixed conditions are evaluated separately from the fitted detectors. The absolute timezone comparator triggers above −480 minutes; the fixed-height comparator triggers above 710 CSS pixels. These are the study's fixed comparators, not universal Web-validity limits or tuned state-of-the-art baselines. Their selection chronology is not established by the available artifacts, so these comparisons are exploratory mechanism evidence rather than independently validated threshold comparisons.

![Figure 3. Three mechanisms by which references contextualize Web reports.](figures/figure_03_mechanisms.png)

**Figure 3.** Schematic mechanisms: device-specific context, interpretation of legitimate co-change, and container context. The illustrations are not measured traces. In panel (b), co-change is interpreted after converting the Native offset to the Web API sign convention; raw Native and Web offsets have opposite signs. Geometry remains a standalone condition.

**Table 4. Exploratory specialist comparisons.** Prespecification of comparator values is not established by the supplied artifacts. Normal system changes (6) and layout changes (6) are included in their respective normal denominators. U and FAILED are zero throughout. Six no-effect memory operations are excluded from both the 18 effective modifications and the 48 normals.

| Study | Fixed check | Detected / modified | Normal alarms |
| --- | --- | --- | --- |
| Memory | Web memory > 8 GiB | 6/18 | 0/48 |
| Memory | Native memory envelope | 18/18 | 0/48 |
| Timezone | Absolute Web offset | 6/6 | 6/30 |
| Timezone | Native timezone reference | 6/6 | 0/30 |
| Geometry | Fixed Web height | 6/6 | 6/66 |
| Geometry | Same-Web viewport relation | 0/6 | 0/66 |
| Geometry | Host upper bound (standalone) | 6/6 | 0/66 |

The Native memory envelope detects 18/18 modifications versus 6/18 for the global threshold, with 0/48 normal alarms for both. Twelve additional detections concern upward changes to 4 and 8 GiB; both checks detect six changes to 16 GiB. The six no-effect operations targeting 2 GiB trigger neither check. This is evidence for the tested upward comparisons, not all downward or coordinated changes. These twelve specialist gains are separate from the nine detections lost in the App ablation.

Both timezone checks detect 6/6 modifications, but the absolute-offset check alarms on six normal system changes while the Native reference does not. Unchanged main-benchmark detection after removing the relation therefore hides a difference in handling legitimate co-change. This is why relations should be assessed on normal changes as well as modification totals.

The fixed Web-height check detects 6/6 modifications but alarms on 6/66 normals. The same-Web viewport relation avoids normal alarms yet misses all six modifications. The Host bound combines 6/6 detection with 0/66 alarms by supplying container context. This result must not replace Integrated App's behavior: configurations 01/02 retain the old height check and alarm on the six normal layout changes; configuration 03 misses the six modifications. Integrating the Host specialist remains separate work.

## 5.3 RQ3: Normal Alarms and Unavailable Evidence

Removing the historical-normal alarm cap raises controlled detections only from 105 to 108 but alarms on every record in both historical groups (Table 5). Both alternatives still have 0/252 controlled-normal alarms. The controlled normals therefore fail to expose a large normal-data cost. Saved uncapped models include broad conditions such as hardware concurrency greater than one and language-list length greater than one; satisfying the controlled budget does not constrain these conditions adequately on the MTC material.

**Table 5. Historical-normal outcomes.** T denotes alarm, F definite no alert, and U unknown. Configurations 01 and 02 have equal counts and are displayed together, not pooled. FAILED and EMPTY_MODEL are zero.

| Cohort | N | Configuration | Integrated App: T / F / U | No cap: T / F / U |
| --- | --- | --- | --- | --- |
| Historical development | 144 | 01 / 02 | 1 / 135 / 8 | 144 / 0 / 0 |
| Historical development | 144 | 03 | 0 / 136 / 8 | 144 / 0 / 0 |
| Historically reserved | 117 | 01 / 02 | 1 / 110 / 6 | 117 / 0 / 0 |
| Historically reserved | 117 | 03 | 0 / 111 / 6 | 117 / 0 / 0 |

On the separate 630 training normals, Integrated App configurations 01/02/03 produce 6/6/0 alarms and 51 unknowns each, whereas uncapped models alarm on all 630. These training outcomes are not added to evaluation counts. Within each Integrated App configuration, the two historical evaluation groups have 14/261 unknown outcomes. Removing memory reduces this to 1/261, alongside the resource detection loss. A binary tree output does not recover unavailable measurements: missing candidate states can exist even when the traversed tree path returns a definite label.

## 5.4 RQ4: Increment from a Linked Browser

On the same 60 positions used to choose the extension, adding C1 increases detection from 2/14 to 7/14 (Table 6). The comparison describes the selected extension on that material rather than future paired-data performance. All five added detections are Browser timezone modifications. App timezone detections are preserved; neither language family gains detection. Both methods have 0/46 normal alarms. All three frozen configurations agree in these counts, which are shown once rather than multiplied into 42 modifications.

**Table 6. Paired App–Browser outcomes.** T is detection for modification rows and alarm for the normal row. U and FAILED are zero on this paired material; it has development-use history.

| Record family | N | Integrated App: T | Integrated App + C1: T |
| --- | --- | --- | --- |
| App timezone | 2 | 2 | 2 |
| App language | 2 | 0 | 0 |
| Browser timezone | 5 | 0 | 5 |
| Browser language | 5 | 0 | 0 |
| Normal alarms | 46 | 0 | 0 |

Historical normals expose an availability cost: adding C1 raises unknowns from 8/144 to 11/144 in development and leaves 6/117 in the historically reserved group, or 14/261 (5.4%) to 17/261 (6.5%) within each model. Alarm counts are unchanged. Since C1 has no timestamp gate, the observed 0/46 does not establish robustness to asynchronous legitimate timezone changes. The language recipes here differ from the language-list recipe detected in the App benchmark. The result supports a targeted increment on the tested timezone operations, not a general benefit from more fields.

## 5.5 Synthesis

References help when they contribute usable context that distinguishes a local report from legitimate variation. On the tested records, memory illustrates device-specific context, timezone illustrates legitimate co-change, and geometry illustrates container context beyond same-Web consistency. The historical and paired results then expose the price of admitting checks: normal alarms and inconclusive outputs. Together, these findings support conditional integrity assessment, with detection, normal alarms, and evidence availability reported jointly.

# 6 Discussion and Limitations

## 6.1 Evidence Is Conditional, Not Attestation

The claim boundary in Section 2.3 also constrains deployment: Native and Host observations share the execution environment, so their practical value depends on which observations an adversary can alter independently. An attacker can preserve a selected constraint without controlling every field or every surface: a memory modification within the envelope already illustrates this possibility. Adaptive optimization and comprehensive coordinated attacks have not been evaluated, so the results establish neither bypass resistance nor increased attacker cost.

## 6.2 Generality, Development Exposure, and Baselines

The attack evidence comes from finite recipes in three emulator environments. Repetition characterizes these settings but does not create independent physical devices. Historical normals broaden observed conditions while retaining development exposure; even the historically reserved label does not turn the current replay into a new blind test. Retrained ablations describe constrained alternatives, and the fixed small tree cannot support a general claim that rules outperform learning. No unified head-to-head evaluation with the related systems in Table 1 is available.

Additional development diagnostics reinforce this limitation: a relation-augmented tree fits the paired material well but does not retain that benefit across both batch-level development checks. Resource extensions likewise improve some development detections but fail the specified admission constraints. Appendix A and the supplemental tables report these outcomes without substituting them for the retained model results.

## 6.3 Availability, Drift, and Integration

Missingness affects both candidate admission and current decisions. The webdriver and WebGL misses locate representation gaps; C1's added unknowns show how an extra reference can reduce definite-output coverage. API changes, WebView provider differences, timing, locale conventions, and container behavior can change the applicable domain. Longitudinal robustness and real-device attack transfer remain unmeasured. A deployable policy for U or FAILED would need separate validation; neither state automatically means normality, attack, or authentication failure.

The reported evaluations contain U outcomes but no FAILED or EMPTY_MODEL outcomes. Failure precedence and receipt rejection remain specified, empirically unexercised behavior; the aggregate artifact cannot independently verify association receipts.

Host geometry is a separate mechanism result, not an integrated detector claim. Its present domain excludes nonzero padding and nonidentity transforms. Integration would require evaluating detection, alarms, availability, and complexity together across window modes, keyboard interactions, and real devices. The study does not establish end-to-end runtime cost. Available cached-evaluation timings exclude collection and communication and are retained only as supplemental implementation diagnostics.

## 6.4 Privacy, Ethics, and Artifact Scope

Environment observations can enable tracking even when collected for integrity checking. WebView research and W3C guidance document this concern [9,12]. Our target is report manipulation, not stable device identity. Controlled manipulations use emulators; historical normals come from cloud-device collection. The documented MTC collector requests network access and network-state observation, not contacts, messages, photos, location, camera, or microphone access. This permission scope does not eliminate fingerprinting privacy risks.

The supplied package contains derived counts and source mappings, not raw device payloads or pairing tickets. Institutional review, exemption, and participant-consent status are not established by the available documentation and must not be inferred from limited permissions. Use of the technique should minimize retained observations and avoid treating uncertain evidence as a basis for automatic denial. The study does not demonstrate an authentication or fraud-reduction outcome.

# 7 Conclusion

HybridGuard studies contextual references for the integrity of Android Web reports. Under the reconstruction protocol, Integrated App and its Web-only and no-memory alternatives differ by nine detections in the CPU-plus-memory recipe. Separate exploratory comparisons illustrate how timezone co-change and Host container context help distinguish the tested modifications from legitimate variation. Historical records expose normal alarms hidden by the controlled benchmark, while the selected Browser extension adds detections and unknown outcomes. These findings motivate compatibility checks that account jointly for applicability, manipulation coverage, normal alarms, and available evidence. Their value remains conditional on the observed references and the scope of the tested predicates.

# References

[1] Furkan Alaca and Paul C. van Oorschot. 2016. Device Fingerprinting for Augmenting Web Authentication: Classification and Analysis of Methods. ACSAC, 289–301. https://doi.org/10.1145/2991079.2991091

[2] Pierre Laperdrix, Nataliia Bielova, Benoit Baudry, and Gildas Avoine. 2020. Browser Fingerprinting: A Survey. ACM Transactions on the Web 14(2), Article 8. https://doi.org/10.1145/3386040

[3] Zengrui Liu, Prakash Shrestha, and Nitesh Saxena. 2022. Gummy Browsers: Targeted Browser Spoofing Against State-of-the-Art Fingerprinting Techniques. ACNS, 147–169. https://doi.org/10.1007/978-3-031-09234-3_8 (Author preprint: https://arxiv.org/abs/2110.10129.)

[4] Antoine Vastel, Pierre Laperdrix, Walter Rudametkin, and Romain Rouvoy. 2018. Fp-Scanner: The Privacy Implications of Browser Fingerprint Inconsistencies. USENIX Security, 135–150. https://www.usenix.org/conference/usenixsecurity18/presentation/vastel

[5] Elie Bursztein, Artem Malyshev, Tadek Pietraszek, and Kurt Thomas. 2016. Picasso: Lightweight Device Class Fingerprinting for Web Clients. SPSM, 93–102. https://doi.org/10.1145/2994459.2994467 (Author page: https://research.google/pubs/picasso-lightweight-device-class-fingerprinting-for-web-clients/.)

[6] Hari Venugopalan, Shaoor Munir, Shuaib Ahmed, Tangbaihe Wang, Samuel T. King, and Zubair Shafiq. 2025. FP-Inconsistent: Measurement and Analysis of Fingerprint Inconsistencies in Evasive Bot Traffic. IMC, 134–149. https://doi.org/10.1145/3730567.3732919 (Author manuscript: https://hariv.github.io/files/fpinconsistent.pdf.)

[7] Maxime Huyghe, Clément Quinton, and Walter Rudametkin. 2025. BrowserFM: A Feature Model-based Approach to Browser Fingerprint Analysis. MADWeb. https://doi.org/10.14722/madweb.2025.23017 (Workshop paper: https://madweb.work/papers/2025/madweb25-huyghe.pdf.)

[8] Abhishek Tiwari, Jyoti Prakash, Alimerdan Rahimov, and Christian Hammer. 2022. Our Fingerprints Don't Fade from the Apps We Touch: Fingerprinting the Android WebView. arXiv:2208.01968. https://arxiv.org/abs/2208.01968

[9] Nipuna Weerasekara, José Miguel Moreno, Srdjan Matic, Joel Reardon, Juan Tapiador, and Narseo Vallina-Rodríguez. 2025. Tracking Without Borders: Studying the Role of WebViews in Bridging Mobile and Web Tracking. PoPETs 2025(4), 745–762. https://doi.org/10.56553/popets-2025-0155

[10] Sohom Datta, Michalis Diamantaris, Ahsan Zafar, Junhua Su, Anupam Das, Jason Polakis, and Alexandros Kapravelos. 2026. Cross-Boundary Mobile Tracking: Exploring Java-to-JavaScript Information Diffusion in WebViews. NDSS. https://doi.org/10.14722/ndss.2026.230910

[11] Android Developers. Build Web Apps in WebView. Living documentation, accessed 22 October 2026. https://developer.android.com/develop/ui/views/layout/webapps/webview

[12] W3C Privacy Working Group. 2025. Mitigating Browser Fingerprinting in Web Specifications. W3C Group Note, 25 September 2025. https://www.w3.org/TR/fingerprinting-guidance/

[13] W3C Web Performance Working Group. 2026. Device Memory API. W3C Discontinued Draft, 20 October 2026. Historical draft, no longer maintained. https://www.w3.org/TR/2026/DISC-device-memory-1-20261020/

[14] Ecma TC39. ECMAScript Language Specification. Date.prototype.getTimezoneOffset. Living specification, accessed 22 October 2026. https://tc39.es/ecma262/multipage/numbers-and-dates.html#sec-date.prototype.gettimezoneoffset

[15] W3C CSS Working Group. CSSOM View Module Level 1. VisualViewport interface. Editor's Draft, accessed 22 October 2026. https://drafts.csswg.org/cssom-view-1/#the-visualviewport-interface
