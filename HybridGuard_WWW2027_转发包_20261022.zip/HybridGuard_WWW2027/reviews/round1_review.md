# HybridGuard Round 1 Independent Review

## Review scope and artifact status

This is an independent content review of the current Markdown manuscript, its section sources, the English appendix, the nine supplied aggregate tables/CSVs, and the three PNG figures. I did not inspect executor notes or earlier reviews. A mechanical PDF build of the same manuscript was inspected only to confirm content continuity; LaTeX, page layout, float placement, and compiler warnings are outside this review by instruction. I did not use or infer anything from the older `source/main.pdf`.

The section files and `HybridGuard_full_draft.md` are content-synchronized after normalizing whitespace and the expected relative figure paths. Spot checks found the headline arithmetic consistent with the supplied aggregates: 105/126, 108/126, 96/126, 72/126, the specialist totals, the 144/117 historical partitions, and the paired 2/14-to-7/14 comparison all transcribe correctly. This establishes presentation consistency, not experimental correctness.

## Overall assessment

**Independent quality score: 5.8/10.** This is a paper-quality score, not an acceptance prediction.

**Submission-ready verdict: NO.** The manuscript has a coherent and unusually careful research story, but it is not ready for formal submission because (i) the ethics/review status is explicitly unresolved, (ii) the central cross-layer effect is smaller and more fragmented than the 105/126 headline initially suggests, (iii) all major evaluation materials have development exposure or narrow emulator scope, and (iv) the detector and comparator construction are not reproducible from the current appendix and released aggregates. The writing is strong enough that a disciplined revision can substantially improve the paper without changing the intended cross-layer report-integrity story, but several evidence limits cannot be repaired by prose alone.

### Score decomposition

| Dimension | Score / 10 | Assessment |
| --- | ---: | --- |
| Problem importance and WWW relevance | 8.0 | Report integrity in WebView-mediated security decisions is relevant and well motivated. |
| Novelty | 5.5 | Cross-layer consistency is established; the novelty is the scoped Android contextualization, four-state semantics, and joint reporting of alarm/availability costs. |
| Technical specification | 6.5 | The state resolution, memory/timezone/geometry relations, and constrained objective are concrete, but the final models and several design choices are underspecified. |
| Claim–evidence alignment | 6.0 | Most prose is carefully qualified, yet the headline system result can still be mistaken for a cross-layer gain. |
| Evaluation rigor | 4.0 | Three emulated environments, known recipes, repeated positions, development reuse, and no independent real-device or attack-family validation limit the evidence. |
| Reproducibility | 3.5 | Aggregate arithmetic is auditable, but final rules, raw records, code, binding receipts, and record-level predictions are absent. |
| Clarity and organization | 8.0 | The manuscript is lucid, internally consistent, and candid about many limitations. |
| Ethics and submission readiness | 2.0 | The paper itself says institutional review/exemption/consent status is not established. |

## Main strengths

1. **The paper preserves the right epistemic boundary.** It repeatedly states that consistency is conditional evidence rather than attestation, identity, malicious intent, or coordinated-attack resistance. This is the correct conceptual stance for the proposed mechanism.

2. **Unknown and failure states are first-class.** The separation of `T`, `F`, `U`, `FAILED`, and `EMPTY_MODEL`, together with failure precedence, is clearer than the common practice of silently mapping missing inputs to a benign label.

3. **The manuscript distinguishes mechanism studies from the integrated detector.** It explicitly says that Host geometry is standalone, the optional Browser is a separate execution context, specialist gains are not complete-model gains, and the small tree is not evidence that rules generally outperform learning.

4. **Adverse outcomes are retained.** The paper reports complete misses for webdriver and WebGL identifiers, the catastrophic all-record alarm behavior of the uncapped model, the Browser extension's availability cost, and negative development diagnostics. This materially improves credibility.

5. **The three mechanism figures support the intended story.** Figure 1 communicates integration boundaries, Figure 2 explains state resolution and offline construction, and Figure 3 separates device context, legitimate co-change, and container context. The illustrations are properly described as conceptual rather than measured traces.

6. **The source package is internally disciplined.** Main text, sections, tables, and aggregate CSVs agree on the reported counts. The appendix also prevents several common misreadings, such as multiplying the same paired records across three frozen models.

## Claim–evidence assessment

| Claim or contribution | Direct supporting evidence | Assessment | Required calibration |
| --- | --- | --- | --- |
| The integrated App detector detects 105/126 effective modifications with 0/252 controlled-normal alarms | Controlled App aggregate and 84 configuration-by-method rows | Numerically supported for the recorded positions | Call this controlled benchmark coverage. The 252 normal positions are paired pre/post positions from 126 runs, not 252 independent trials or devices. |
| Cross-layer information improves the integrated detector | Full App 105/126 vs Web-only 96/126 and no-memory 96/126 | Supported, but the measured integrated increment is nine detections and is attributable to the memory relation on this benchmark | State this decomposition next to every 105/126 headline. Removing timezone does not reduce the aggregate detection total. |
| Native memory gives device-specific context | 18/18 vs 6/18 specialist; nine detections lost in the integrated no-memory ablation | Mechanistically supported for tested upward changes | The envelope remains an engineered heuristic; threshold provenance and independent normal diversity need documentation. |
| Native timezone handles legitimate co-change | Both checks detect 6/6; absolute check alarms on 6/30 while relational check alarms on 0/30 | Supported for six tested system timezone changes | Do not imply a general false-positive result. The comparison threshold and test-case selection need provenance. |
| Host geometry supplies useful container context | 6/6 with 0/66 in the specialist cohort | Supported only as a standalone fixed check | Keep it outside Full App claims until integrated construction and broader window/device conditions are evaluated. |
| Historical-normal constraints prevent broad rules | Uncapped models alert on 144/144 and 117/117, versus 0/1 alarms for Full App depending on fold | Strong dataset-specific evidence | The cohorts have development exposure and uncertain independence; this is a construction lesson, not an external false-positive estimate. |
| Linked Browser timezone adds evidence | 2/14 to 7/14; five Browser-timezone detections | Supported as a development demonstration | The extension was selected and reported on development-used material and has no timestamp gate. It is not independent validation. |
| Four-state semantics make the detector robust to unavailable/failing evidence | Historical records contain `U`; controlled/specialist/paired results contain no `FAILED` or `EMPTY_MODEL` | Partially supported | `U` behavior is observed, but failure and empty-model semantics are specified rather than empirically stress-tested. |
| Provenance binding supports correct association | Design description; source records and receipts are mentioned | Not independently supported by the supplied artifact | Raw receipts, pairing tickets, code, or an auditable binding trace are needed for independent verification. |

## Prioritized issues

### CRITICAL-1 — Ethics/review status is unresolved in the manuscript

**Type:** submission blocker; provenance/administrative evidence gap, not a writing-only issue.

**Triggering text:** “Institutional review, exemption, and participant-consent status are not established by the available documentation and must not be inferred from limited permissions.”

This sentence is candid, but a formal paper cannot leave the ethical status of fingerprint-like cloud-device collection unknown. The permission list does not answer whether the work used human participants, real user accounts, provider-owned test devices, customer traffic, or data subject to institutional review. A reviewer cannot infer exemption on the authors' behalf.

**Required action before submission:** determine and state the actual collection provenance, ownership/control of devices and accounts, collection dates, data-retention policy, whether any human/user data were present, and the institutional determination. If an IRB/ethics board was consulted, provide the true determination and protocol identifier where permitted. If review was not required, state the institution's actual policy basis. If this provenance cannot be established, the historical material should not support submission claims.

**Exact replacement template (must be filled only with verified facts):**

> All controlled manipulations used emulators. The MTC records were collected on [owned/rented/provider-operated test devices] between [dates] using [test accounts/no user accounts]. We collected [exact data classes] and no [verified excluded human/user data classes]. [Institutional body] determined on [date] that this study was [exempt/not human-subjects research/approved] under [protocol or policy reference]. We retained [derived/raw] records for [period] and applied [access/deletion controls].

Do not submit with bracketed placeholders or a guessed determination.

### MAJOR-1 — The headline 105/126 result is not itself the cross-layer effect

**Type:** claim–evidence calibration; writing-fixable with the current data.

**Triggering text:** “Across 14 controlled manipulation configurations in three emulator environments, Full App detects 105/126 effective modifications (83.3%), with 0/252 controlled-normal alarms.”

The integrated evidence shows 105/126 for Full App, 96/126 for Web-only, and 96/126 for no-memory. Thus the integrated cross-layer increment is nine detections, concentrated in the Native memory relation. Removing Native timezone leaves 105/126 because an absolute condition substitutes. Host geometry is standalone. Most of the 105 detections are shared with Web-only checks. The manuscript later explains this, but the abstract, title, and introductory headline still invite a stronger reading.

**Required action:** place the nine-detection decomposition immediately beside the 105/126 number; identify timezone value as normal-change interpretation rather than aggregate detection gain; keep Host geometry explicitly standalone. Consider replacing “Full App,” which sounds as if it includes Host and Browser, with “Native+App-Web detector” or “integrated App detector.”

**Exact replacement for the first RQ1 paragraph:**

> The Native+App-Web detector identifies 105/126 effective modifications (83.3%) and raises no alarms on the 252 controlled-normal record positions. A separately reconstructed Web-only detector identifies 96/126; the nine-position difference is also lost when the Native-memory relation is removed. Removing the Native-timezone relation leaves the aggregate total unchanged because an absolute-offset condition substitutes on this benchmark. Thus, the 105/126 total is overall detector coverage, while the measured integrated cross-layer increment in this benchmark is the nine memory-related detections.

### MAJOR-2 — All principal evaluation claims are development-exposed or narrowly controlled

**Type:** evidence gap; cannot be repaired by prose alone if the desired claim is generalization.

**Triggering text:** “Development exposure to these environments and recipes prevents interpreting the split as unseen-tool or physical-device attack generalization.” Also: “60 development-used positions: pilot 18 + matched 42.”

The held-out unit is an emulator environment, but all three environments and all manipulation recipes were known during development. Repetitions characterize execution stability; they do not add independent devices or attacks. The MTC “historically reserved” group has development-use history, and the Browser extension is selected and reported on the same 60 development-used positions. This is acceptable for a scoped mechanism paper, but not for claims of attack generalization, deployable false-positive behavior, or external validation.

**Writing-only fallback:** consistently call the study a “controlled mechanism evaluation” and the counts “coverage of recorded effective modifications.” Avoid “held-out generalization,” “validation cohort,” “false-positive rate,” and “robustness” except when explicitly negated.

**Evidence needed for a stronger paper:** a newly blinded cohort with real devices/WebView providers and at least one unseen manipulation family; separately acquired nominal records; and a paired Browser cohort containing legitimate asynchronous timezone changes. These are new-data requirements and should not be fabricated or implied.

**Exact replacement for the RQ4 opening:**

> On the 60 development-used paired positions, adding C1 changes detection from 2/14 to 7/14, with all five added detections coming from Browser-timezone modifications. Because C1 was selected using these materials, this result demonstrates the mechanism on the development corpus and is not an independent estimate of future paired-data performance.

### MAJOR-3 — Comparator thresholds and semantic bounds lack selection provenance

**Type:** methodological clarity; potentially an evidence gap.

**Triggering text:** “The fixed Web-only comparator tests m_web > 8 GiB.” Appendix A.2 adds: “The fixed timezone comparator alerts above -480 minutes; the old Web-height comparator alerts above 710 CSS pixels.”

The specialist comparisons drive the paper's three mechanism claims, yet the paper does not say whether 8 GiB, -480 minutes, 710 CSS pixels, the memory power-of-two envelope, or the Host tolerance were prespecified from platform semantics, chosen on development data, or selected after inspecting the specialist cohorts. If absolute baselines were chosen post hoc or poorly, the reported relation advantage is not a fair causal comparison. The memory bound also needs a browser/API-semantics citation or a clear declaration that it is a tested engineering heuristic rather than a platform invariant.

**Required action:** for every fixed check, report the rule's source, selection time, selection material, and sensitivity range. If a threshold used any evaluated specialist records, label the comparison exploratory. If the true provenance is unavailable, do not describe the result as evidence that relational checks generally outperform absolute checks.

**Exact appendix text, choosing only the factually correct branch:**

> Comparator provenance. The 8-GiB memory, -480-minute timezone, and 710-CSS-pixel height thresholds were [prespecified from the following documented platform semantics: … / selected exclusively on development material: … / selected after inspection of the specialist cohort and are therefore exploratory]. No record reported as independent evaluation was used to select [identify the rules for which this is true]. The power-of-two memory envelope and geometry tolerance are engineering hypotheses, not Android or Web platform guarantees; our evidence concerns only the listed domains and tested values.

### MAJOR-4 — The final detector cannot be reconstructed from the manuscript or appendix

**Type:** reproducibility gap; partly fixable from existing artifacts if they exist.

**Triggering text:** “The App pool contains 50 base templates and three fixed relations” and “same-group swaps use registered higher-quality alternatives.”

The paper gives pool sizes and constraints but not the 50 template definitions, atom encodings, admitted atoms, final selected clauses/thresholds per fold, retention sequence, “higher-quality” ordering, or exact fold membership. The appendix identifies model names but not their contents. The artifact explicitly excludes raw payloads and original detector source. Therefore a reader can verify arithmetic but cannot reproduce predictions or audit why a record triggered.

**Required action using existing material:** add an appendix table for every final and ablated fold listing condition ID, operands, source layers, applicability rule, polarity, threshold, construction stage, and final inclusion. Define the quality ordering and tie-breaking deterministically. Publish record identifiers and record-level outcomes if raw values cannot be released. State an artifact-release plan for code and binding logic.

**Exact appendix insertion:**

> Reconstructing the saved detectors. Appendix Table A1 lists, for folds F29/F30/F36, every final condition with its stable ID, operands, source layer, applicability predicate, polarity, threshold, family, selection stage, and clause membership. Table A2 provides the same information for each ablation. The deterministic proposal order and all tie breakers are [specified here/released at artifact path …]. Record-level predictions are keyed by anonymized record IDs so that each aggregate cell can be regenerated without access to raw fingerprint values.

This text is only valid after the promised tables/artifacts exist.

### MAJOR-5 — Observation positions are repeatedly presented in ways that can be read as independent samples

**Type:** statistical-unit clarity; writing-fixable, with a remaining evidence limit.

**Triggering text:** “Fourteen configurations, three repetitions, and three environments yield 126 effective modifications. Each admitted run contributes normal pre- and confirmed post-records, yielding 252 normals.”

The 126 modifications are structured cells, and the 252 normals are two correlated positions from those same 126 runs. The 891 MTC entries are manufacturer/model/release representatives rather than independent devices. Reporting 83.3% and 0/252 is arithmetically correct, but the precision looks like a sample-based rate unless the unit is restated near the results. No population confidence claim should be implied.

**Exact text to add below Table 3:**

> Statistical unit. These percentages summarize recorded positions in a fixed factorial benchmark. The 252 controlled-normal positions comprise two positions from each of 126 manipulation runs, and repetitions within an emulator environment are not independent devices. We therefore report descriptive coverage and alarm counts rather than population estimates or confidence intervals.

For MTC, use “nominal record positions” rather than “normal devices” or “false positives.” The current term “normal alarm” is defensible only because Section 4.1 carefully defines normal as absence of the study-defined target manipulation.

### MAJOR-6 — State-aware and provenance-bound behavior is more specified than empirically evaluated

**Type:** claim–evidence gap; writing-fixable for scope, new evidence required for operational robustness.

**Triggering text:** “Its detector combines selected checks while preserving unknown outcomes and execution failures.” Also: “Source records and receipts support tracing and binding checks.”

Historical records exercise `U`, but all controlled, specialist, and paired tables have zero `FAILED`, and no result exercises `EMPTY_MODEL`. Binding failures, conflicting provenance, malformed receipts, and failure-versus-trigger precedence are not evaluated. The supplied package excludes pairing tickets and raw payloads. The semantics are technically well specified, but the paper cannot yet claim that their implementation is robust in adversarial or operational conditions.

**Exact limitation sentence:**

> The present evaluation observes unknown outcomes on historical records but contains no `FAILED` or `EMPTY_MODEL` outcomes. Failure precedence and binding rejection are therefore specified design behavior, not empirically validated robustness claims; the supplied aggregates also do not permit independent audit of association receipts.

If existing unit or fault-injection tests already exist, release and cite them. Otherwise, empirical failure-handling evidence would require additional testing.

### MAJOR-7 — Baselines support diagnosis, not competitive positioning

**Type:** novelty/evaluation boundary; evidence gap for any superiority claim.

**Triggering text:** “Full App detects 105 modifications, compared with 96 for Web-only and 72 for a fixed candidate-state tree.”

The Web-only ablation is valuable, but it changes the constructible feature space and is not a pure causal intervention. The depth-three tree shares the hand-engineered candidate representation and was not tuned as a competitive learner. The three fixed absolute checks have unclear selection provenance. No related security system is run under a shared protocol. The paper acknowledges these facts later, but placing 72/126 in the introduction still invites a “rules beat ML” reading.

**Required action:** remove the tree number from the introductory headline or call it a capacity-controlled diagnostic. Frame Table 1 as conceptual positioning and the evaluation as within-artifact ablation/mechanism evidence. A competitive or state-of-the-art claim would require new baseline implementations and data and is unsupported here.

**Exact introductory replacement:**

> The controlled App benchmark contains 126 effective modifications and 252 controlled-normal record positions. The integrated detector identifies 105 modifications, while a separately reconstructed Web-only detector identifies 96. A depth-three candidate-state tree is included only as a fixed-capacity diagnostic and does not establish that rule models outperform machine learning.

## Minor issues and exact fixes

### MINOR-1 — “Full App” is misleading

It excludes Host geometry and the optional Browser, so “Full” overstates surface coverage. Rename it throughout as **Native+App-Web detector** or **Integrated App detector**. Keep “Host-geometry specialist” and “App+Browser C1” separate.

### MINOR-2 — “Configuration” is overloaded

The paper has 14 manipulation configurations and three model configurations 01/02/03. Rename the latter **folds F29, F30, and F36**, indicating the held-out API environment. This will make Table 5 and the appendix easier to parse.

### MINOR-3 — App177, Browser67, and paired244 look like unexplained product names

Replace with direct schema notation. Exact replacement:

> The App schema contains 177 catalogued fields: 84 Native, 26 Host, and 67 App-Web fields. The optional external-Browser schema contains 67 fields; a valid association yields a 244-field paired schema. These are schema counts, not independent signals or selected-model inputs.

### MINOR-4 — The construction objective needs a more explicit index definition

The definition of `d_k(S)` is difficult to reconstruct. State the environment index, training fold, per-configuration denominator, and macro-averaging order in an equation. Also state how ties are broken and whether the 60-second deadline ever truncates a search.

### MINOR-5 — Figure 2 uses a dash where the text uses `U`

Replace the gray “–” output in “Check N” with a literal `U`, or add a legend that the dash denotes unknown. The figure should visually include all four condition states if four-state semantics are a contribution.

### MINOR-6 — Figure 3(b) can obscure timezone sign normalization

The same-direction arrows for “System timezone” and “Web offset” are intuitive but can conflict with the text's explicit sign inversion. Rename them **Native-derived offset (Web sign)** and **Web `getTimezoneOffset`**. This prevents readers from interpreting raw offsets as directly comparable.

### MINOR-7 — Figure 1 field counts may imply that all fields are model inputs

Add “catalogued schema fields; selected checks use a subset” to the caption or remove the counts from the graphic. The current prose makes this clear, but the figure can circulate without that paragraph.

### MINOR-8 — The related-work base is too narrow for several API and mechanism choices

The bibliography adequately covers the immediate fingerprint-consistency lineage but does not ground `deviceMemory`, viewport/scale semantics, timezone APIs/tzdb behavior, WebDriver/automation semantics, or the choice of cloud-device normal material. Add primary specifications and platform documentation that directly justify the implemented relations. This is a citation gap, not a request to claim novelty by citation volume.

### MINOR-9 — Availability costs should be expressed as rates once

Alongside 14/261 and 17/261, report 5.4% and 6.5% to make the operational change legible. Keep counts primary because the cohorts are not independent population samples.

## Proposed replacement abstract

The current abstract is 254 words and gives the 105/126 headline before exposing its cross-layer decomposition. The following version preserves the paper's story while making the evidence hierarchy explicit:

> Browser-visible environment reports can inform security decisions but can be altered independently of the underlying device. We study whether associated Android Native and WebView Host observations can provide conditional integrity evidence for App-Web reports. HybridGuard binds observations to an execution, evaluates semantic relations under explicit applicability conditions, and preserves true, false, unknown, and failure states. On 126 effective modifications from 14 known recipes in three emulated environments, the Native+App-Web detector identifies 105 modifications and raises no alarms on 252 controlled-normal record positions. Its integrated Native-memory relation accounts for the nine detections beyond a separately reconstructed Web-only detector; removing the Native-timezone relation does not change this benchmark total. Separate fixed-check studies expose the mechanisms more directly: a Native-memory envelope detects 18/18 tested upward modifications versus 6/18 for a global Web threshold, while Native timezone and standalone Host geometry references each avoid six alarms raised by their absolute comparators. Removing the historical-normal alarm cap gains three controlled detections but alerts on every replayed historical record. On development-used paired data, an optional Browser-timezone relation adds five detections while increasing historical unknown outcomes from 14/261 to 17/261 per model. These controlled results demonstrate context-dependent integrity evidence, not attestation, unseen-attack generalization, or resistance to coordinated manipulation.

## Proposed contribution paragraph

> This paper makes three scoped contributions. First, it defines provenance-bound, state-aware consistency evaluation for associated Android Native, Host, and App-Web observations, including explicit unknown and failure semantics. Second, it isolates three mechanisms by which contextual references can help on the tested data: a device-specific memory bound, interpretation of legitimate timezone co-change, and a standalone Host geometry bound. Third, it shows that detector construction must account jointly for manipulation coverage, alarms on nominal records, and unavailable evidence. The integrated benchmark improvement is concentrated in the Native-memory relation; the timezone and Host claims come from separate fixed-check comparisons, and the optional Browser result is development-only.

## Writing-fixable versus evidence-limited items

| Can be repaired with writing and existing saved metadata | Requires missing provenance/artifacts but not necessarily new experiments | Requires new data or new evaluation to strengthen the claim |
| --- | --- | --- |
| State the nine-detection integrated increment beside 105/126 | Verified ethics/IRB or exemption determination | Newly blinded real-device/WebView-provider cohort |
| Rename Full App and model folds | Exact final rule/atom/threshold tables | Unseen manipulation families |
| Label Browser results development-only | Comparator threshold provenance | Adaptive/coordinated manipulation evaluation |
| Clarify record-position dependence and descriptive rates | Record IDs and record-level outcomes | Legitimate asynchronous paired-timezone changes |
| Add failure-semantics limitation | Code, binding logic, receipts, or auditable traces | Independent competitive baselines under a shared protocol |
| Fix figure labels and remove repeated scope caveats | MTC collection provenance and sampling metadata | Operational `FAILED`/binding-failure stress tests if robustness is claimed |

## Minimum revision gate before the next review round

1. Resolve and replace the ethics-status paragraph with verified facts.
2. Rewrite the abstract, introduction headline, and RQ1 opening so 105/126 cannot be mistaken for 105 cross-layer detections.
3. Add comparator provenance and a complete final-model specification to the appendix.
4. Relabel all development-used and non-independent materials consistently.
5. Add the explicit limitation that `FAILED`, `EMPTY_MODEL`, and binding rejection are not empirically evaluated here.
6. If no new data will be collected, lock the paper's identity as a controlled mechanism and design study. Do not imply deployment readiness, attack-family generalization, or population false-positive performance.

## Final verdict

**Not submission ready.** The paper is close to a strong, honest mechanism-study manuscript, but the unresolved ethics statement alone prevents formal submission. After that is fixed, the highest-value revision is to make the cross-layer effect decomposition impossible to miss and to make the saved detector/comparator construction auditable. Without new data, the manuscript can still become credible by embracing its controlled, development-exposed scope. A broader security-performance claim would require independent real-device and unseen-attack evidence.
