| Work | Evidence examined | Research focus | Focus of the present study |
| --- | --- | --- | --- |
| FP-Scanner [4] | Browser attributes; JavaScript/HTTP discrepancies | Countermeasure-induced inconsistencies | Associated Native and Host references |
| Picasso [5] | Canvas challenge responses | Claimed device-class checking | Current-record semantic compatibility |
| FP-Inconsistent [6] | Within-request and temporal inconsistencies | Evasive bot traffic | Controlled edits versus normal changes |
| BrowserFM [7] | Fingerprint/configuration dependencies | Configuration modeling and analysis | Applicability and evidence-availability costs |
| WebView studies [8–10] | App, JavaScript, and runtime observations | Exposure and cross-boundary tracking | Report-integrity assessment |
| HybridGuard | Native, Host, App Web; optional Browser | Contextual references under explicit domains | Detection, normal alarms, and unknown outcomes |
