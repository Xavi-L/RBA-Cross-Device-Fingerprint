| Method | Detected / modified | Detection (%) | Missed | Normal alarms |
| --- | --- | --- | --- | --- |
| Integrated App | 105/126 | 83.3 | 21 | 0/252 |
| No MTC cap | 108/126 | 85.7 | 18 | 0/252 |
| Web-only | 96/126 | 76.2 | 30 | 0/252 |
| No memory | 96/126 | 76.2 | 30 | 0/252 |
| No timezone | 105/126 | 83.3 | 21 | 0/252 |
| App tree | 72/126 | 57.1 | 54 | 0/252 |
