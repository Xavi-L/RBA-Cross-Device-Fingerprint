| Material | Effective modifications | Normal records | Evaluation role |
| --- | --- | --- | --- |
| Controlled App | 126 | 252 | 14 configurations × 3 repetitions × 3 environments; disjoint held-out positions |
| MTC discovery | — | 630 | Training-side constraints and tree training |
| MTC historical development | — | 144 | Historical evaluation with development exposure |
| MTC historically reserved | — | 117 | Historical evaluation; not a newly blinded cohort |
| Memory specialist | 18 | 48 | Fixed checks; 6 no-effect operations excluded |
| Timezone specialist | 6 | 30 | Includes 6 normal system changes |
| Geometry specialist | 6 | 66 | Includes 6 normal layout changes; not integrated |
| Paired App–Browser | 14 | 46 | 60 development-used positions: pilot 18 + matched 42 |
