| Record family | N | Integrated App: T | Integrated App + C1: T |
| --- | --- | --- | --- |
| App timezone | 2 | 2 | 2 |
| App language | 2 | 0 | 0 |
| Browser timezone | 5 | 0 | 5 |
| Browser language | 5 | 0 | 0 |
| Normal alarms | 46 | 0 | 0 |
