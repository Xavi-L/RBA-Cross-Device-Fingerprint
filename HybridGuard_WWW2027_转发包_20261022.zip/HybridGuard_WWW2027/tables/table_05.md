| Cohort | N | Configuration | Integrated App: T / F / U | No cap: T / F / U |
| --- | --- | --- | --- | --- |
| Historical development | 144 | 01 / 02 | 1 / 135 / 8 | 144 / 0 / 0 |
| Historical development | 144 | 03 | 0 / 136 / 8 | 144 / 0 / 0 |
| Historically reserved | 117 | 01 / 02 | 1 / 110 / 6 | 117 / 0 / 0 |
| Historically reserved | 117 | 03 | 0 / 111 / 6 | 117 / 0 / 0 |
