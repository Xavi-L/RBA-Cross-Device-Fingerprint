| Study | Fixed check | Detected / modified | Normal alarms |
| --- | --- | --- | --- |
| Memory | Web memory > 8 GiB | 6/18 | 0/48 |
| Memory | Native memory envelope | 18/18 | 0/48 |
| Timezone | Absolute Web offset | 6/6 | 6/30 |
| Timezone | Native timezone reference | 6/6 | 0/30 |
| Geometry | Fixed Web height | 6/6 | 6/66 |
| Geometry | Same-Web viewport relation | 0/6 | 0/66 |
| Geometry | Host upper bound (standalone) | 6/6 | 0/66 |
