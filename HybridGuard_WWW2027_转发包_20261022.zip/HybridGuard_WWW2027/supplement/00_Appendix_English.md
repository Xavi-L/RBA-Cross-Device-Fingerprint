# Appendix A. Configuration and Reproducibility Details

## A.1 Saved Model Identities

The three App configurations hold out emulator API 29, 30, and 36, respectively. APP_FULL denotes the retained B_REL_TZ models. A_NO_MTC_CAP, A_APP_WEB_ONLY, A_NO_MEMORY_REL, and A_NO_TIMEZONE_REL denote reconstructed alternatives, not specialist substitutions. APP_TREE uses saved FITTED outputs; the rule alternatives use saved RETENTION outputs. PAIRED_BASE is the frozen App detector plus C1.

The candidate-state tree uses scikit-learn 1.7.2, splitter=best, random_state=20261006, no class-weight override, and a positive-class probability threshold of 0.5. Its admitted inputs contain 63, 63, and 54 atoms, each represented by three state indicators. These differ from the pre-admission pools. Fifteen positions per controlled held-out set and 73 of the 891 MTC records contain an unknown candidate; the saved decision paths need not use those candidates. Binary output is not evidence of complete observation.

## A.2 Candidate Admission and Extension Choice

Threshold expansion uses training-only quantiles 0.25, 0.5, and 0.75. Candidate support requires at least three complete true/false triplets and at least two triggered modification triplets in at least one bundle/environment, alongside normal assessability. The browser-extension candidates are none, C1, C2, and C1+C2. Feasible sets are ranked by the equal mean of detection ratios across App timezone, App language, Browser timezone, and Browser language, then fewer additions and a fixed set order. This is development-side selection, not independent validation.

The fixed timezone comparator alerts above -480 minutes; the old Web-height comparator alerts above 710 CSS pixels. Native timezone uses effective offsets under the implementation's fixed timezone database. Geometry uses the domain and tolerance in Section 3.3. C1 requires both status and quality markers, accepts finite numeric offsets including zero and minus one, and has no timestamp acceptance gate.

## A.3 Full Tables and Statistical Units

S01–S09 preserve all nine supplied aggregate tables without replacing adverse outcomes. Source field names remain in Chinese to preserve the input schema. The main manuscript contains English presentation tables. S02 contains 14 configurations × 6 methods = 84 rows. The five equivalent count-pattern groups have sizes 1, 1, 2, 8, and 2, with nine effective modifications per original configuration. Their weighted sums reproduce 105, 108, 96, 96, 105, and 72 detections. Language-list changes in this benchmark are not interchangeable with language operations in the paired cohort.

S07 records resource-admission comparisons on 26 modified and 718 normal development positions, with a separate historical replay of 261 normals. S0 detects 13/26; S0+M and S0+W detect 19/26; S0+B detects 16/26. The additions fail the recorded coverage and/or normal-alarm admission criteria. These counts do not replace the retained App-plus-C1 results on 14 paired modifications.

S08 is a four-view development diagnostic. The relation-augmented P0 fit has 14/14 detections and 0/46 normal alarms. Under P2, the relation-augmented view has 4/8 detections and 6/34 alarms. These settings are not independent replications. S09 times cached_from_adapted execution for batches of 60 over ten rounds. Its microseconds-per-position medians and batch-amortized p95 values exclude acquisition and communication. They are neither per-request latency percentiles nor end-to-end deployment costs.

## A.4 Presentation Audit Scope

The verification script checks state partitions, App aggregate/detail agreement, supplied row counts, image links, table references, and package hashes. It verifies consistency of saved summaries and presentation, not detector correctness, independent sample identities, or newly executed experiments. Raw payloads, collection logs, pairing tickets, and original detector source are outside the supplied materials.

## A.5 Specification and Provenance Boundaries

The saved aggregate labels 01, 02, and 03 identify the models that hold out API 29, 30, and 36, respectively. They are model identifiers, distinct from the 14 manipulation recipes. APP_FULL is called Integrated App in the main text; this rename does not add Host geometry or Browser inputs to that detector.

The supplied artifacts record comparator values of 8 GiB, −480 minutes, and 710 CSS pixels, but do not establish when or on which records these values were chosen. The fixed-check results are consequently exploratory. The power-of-two memory envelope and geometry tolerance are engineering hypotheses within the stated domains, not platform guarantees. No threshold-sensitivity experiment is available.

The current artifact supports aggregate reconciliation, not full detector reconstruction. It does not supply the complete 50-template catalogue, final per-model condition lists, deterministic retention ordering, record-level predictions, or an execution trace establishing whether the fit deadline affected a search. Pool sizes and construction constraints do not substitute for these missing specifications. The reported counts refer to saved models; this paper does not claim that independently rerunning the description must reproduce them.
