# 6 Discussion and Limitations

## 6.1 Evidence Is Conditional, Not Attestation

The claim boundary in Section 2.3 also constrains deployment: Native and Host observations share the execution environment, so their practical value depends on which observations an adversary can alter independently. An attacker can preserve a selected constraint without controlling every field or every surface: a memory modification within the envelope already illustrates this possibility. Adaptive optimization and comprehensive coordinated attacks have not been evaluated, so the results establish neither bypass resistance nor increased attacker cost.

## 6.2 Generality, Development Exposure, and Baselines

The attack evidence comes from finite recipes in three emulator environments. Repetition characterizes these settings but does not create independent physical devices. Historical normals broaden observed conditions while retaining development exposure; even the historically reserved label does not turn the current replay into a new blind test. Retrained ablations describe constrained alternatives, and the fixed small tree cannot support a general claim that rules outperform learning. No unified head-to-head evaluation with the related systems in Table 1 is available.

Additional development diagnostics reinforce this limitation: a relation-augmented tree fits the paired material well but does not retain that benefit across both batch-level development checks. Resource extensions likewise improve some development detections but fail the specified admission constraints. Appendix A and the supplemental tables report these outcomes without substituting them for the retained model results.

## 6.3 Availability, Drift, and Integration

Missingness affects both candidate admission and current decisions. The webdriver and WebGL misses locate representation gaps; C1's added unknowns show how an extra reference can reduce definite-output coverage. API changes, WebView provider differences, timing, locale conventions, and container behavior can change the applicable domain. Longitudinal robustness and real-device attack transfer remain unmeasured. A deployable policy for U or FAILED would need separate validation; neither state automatically means normality, attack, or authentication failure.

The reported evaluations contain U outcomes but no FAILED or EMPTY_MODEL outcomes. Failure precedence and receipt rejection remain specified, empirically unexercised behavior; the aggregate artifact cannot independently verify association receipts.

Host geometry is a separate mechanism result, not an integrated detector claim. Its present domain excludes nonzero padding and nonidentity transforms. Integration would require evaluating detection, alarms, availability, and complexity together across window modes, keyboard interactions, and real devices. The study does not establish end-to-end runtime cost. Available cached-evaluation timings exclude collection and communication and are retained only as supplemental implementation diagnostics.

## 6.4 Privacy, Ethics, and Artifact Scope

Environment observations can enable tracking even when collected for integrity checking. WebView research and W3C guidance document this concern [9,12]. Our target is report manipulation, not stable device identity. Controlled manipulations use emulators; historical normals come from cloud-device collection. The documented MTC collector requests network access and network-state observation, not contacts, messages, photos, location, camera, or microphone access. This permission scope does not eliminate fingerprinting privacy risks.

The supplied package contains derived counts and source mappings, not raw device payloads or pairing tickets. Institutional review, exemption, and participant-consent status are not established by the available documentation and must not be inferred from limited permissions. Use of the technique should minimize retained observations and avoid treating uncertain evidence as a basis for automatic denial. The study does not demonstrate an authentication or fraud-reduction outcome.
