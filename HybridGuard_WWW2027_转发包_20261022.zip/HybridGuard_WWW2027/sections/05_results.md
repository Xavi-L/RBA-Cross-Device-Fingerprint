# 5 Results

## 5.1 RQ1: Detection and Component Comparisons

Integrated App covers 105 of 126 controlled modification positions, with 0/252 controlled-normal alarms (Table 3). The reconstructed Web-only and no-memory alternatives each cover 96/126; all nine differences occur in the CPU-plus-memory recipe. This is a component association under the reconstruction protocol, not a causal effect of deleting a condition from a frozen model. No-timezone preserves 105/126 because an absolute-offset condition substitutes on this benchmark. Removing the MTC cap gains three screen detections; Section 5.3 examines the normal-data cost. The App tree detects 72/126 under its fixed representation and capacity.

**Table 3. Controlled benchmark-position outcomes.** All methods have zero U, FAILED, and EMPTY_MODEL counts on these held-out positions. Ablations are separately reconstructed models.

| Method | Detected / modified | Detection (%) | Missed | Normal alarms |
| --- | --- | --- | --- | --- |
| Integrated App | 105/126 | 83.3 | 21 | 0/252 |
| No MTC cap | 108/126 | 85.7 | 18 | 0/252 |
| Web-only | 96/126 | 76.2 | 30 | 0/252 |
| No memory | 96/126 | 76.2 | 30 | 0/252 |
| No timezone | 105/126 | 83.3 | 21 | 0/252 |
| App tree | 72/126 | 57.1 | 54 | 0/252 |

These percentages describe positions in a fixed factorial benchmark. The 252 controlled-normal positions comprise two correlated positions from each of 126 manipulation runs. Repetitions within an emulator environment do not create independent devices; the counts are descriptive summaries, not population estimates.

At recipe level, Integrated App detects 9/9 CPU-plus-memory modifications and 6/9 screen modifications. It detects all nine instances of each timezone-only and plugins/MIME configuration, as well as all eight shared-detection configurations: Playwright, Puppeteer, CDP multi-field, and Stealth presets; platform-only, UA-only, UA-plus-platform, and language-list modifications. All six methods miss 9/9 webdriver-only and 9/9 WebGL-identifier modifications. Historical raw WebGL unavailability and lost webdriver-false semantics limit admission of the corresponding candidates. The saved analysis attributes these misses to representation and admission limitations; the aggregate counts alone do not establish intrinsic undetectability. Appendix A preserves the recipe grouping and supplemental tables contain all 84 configuration-by-method cells.

## 5.2 RQ2: What References Contribute

Exploratory fixed checks illustrate three complementary mechanisms (Figure 3; Table 4). These fixed conditions are evaluated separately from the fitted detectors. The absolute timezone comparator triggers above −480 minutes; the fixed-height comparator triggers above 710 CSS pixels. These are the study's fixed comparators, not universal Web-validity limits or tuned state-of-the-art baselines. Their selection chronology is not established by the available artifacts, so these comparisons are exploratory mechanism evidence rather than independently validated threshold comparisons.

![Figure 3. Three mechanisms by which references contextualize Web reports.](../figures/figure_03_mechanisms.png)

**Figure 3.** Schematic mechanisms: device-specific context, interpretation of legitimate co-change, and container context. The illustrations are not measured traces. In panel (b), co-change is interpreted after converting the Native offset to the Web API sign convention; raw Native and Web offsets have opposite signs. Geometry remains a standalone condition.

**Table 4. Exploratory specialist comparisons.** Prespecification of comparator values is not established by the supplied artifacts. Normal system changes (6) and layout changes (6) are included in their respective normal denominators. U and FAILED are zero throughout. Six no-effect memory operations are excluded from both the 18 effective modifications and the 48 normals.

| Study | Fixed check | Detected / modified | Normal alarms |
| --- | --- | --- | --- |
| Memory | Web memory > 8 GiB | 6/18 | 0/48 |
| Memory | Native memory envelope | 18/18 | 0/48 |
| Timezone | Absolute Web offset | 6/6 | 6/30 |
| Timezone | Native timezone reference | 6/6 | 0/30 |
| Geometry | Fixed Web height | 6/6 | 6/66 |
| Geometry | Same-Web viewport relation | 0/6 | 0/66 |
| Geometry | Host upper bound (standalone) | 6/6 | 0/66 |

The Native memory envelope detects 18/18 modifications versus 6/18 for the global threshold, with 0/48 normal alarms for both. Twelve additional detections concern upward changes to 4 and 8 GiB; both checks detect six changes to 16 GiB. The six no-effect operations targeting 2 GiB trigger neither check. This is evidence for the tested upward comparisons, not all downward or coordinated changes. These twelve specialist gains are separate from the nine detections lost in the App ablation.

Both timezone checks detect 6/6 modifications, but the absolute-offset check alarms on six normal system changes while the Native reference does not. Unchanged main-benchmark detection after removing the relation therefore hides a difference in handling legitimate co-change. This is why relations should be assessed on normal changes as well as modification totals.

The fixed Web-height check detects 6/6 modifications but alarms on 6/66 normals. The same-Web viewport relation avoids normal alarms yet misses all six modifications. The Host bound combines 6/6 detection with 0/66 alarms by supplying container context. This result must not replace Integrated App's behavior: configurations 01/02 retain the old height check and alarm on the six normal layout changes; configuration 03 misses the six modifications. Integrating the Host specialist remains separate work.

## 5.3 RQ3: Normal Alarms and Unavailable Evidence

Removing the historical-normal alarm cap raises controlled detections only from 105 to 108 but alarms on every record in both historical groups (Table 5). Both alternatives still have 0/252 controlled-normal alarms. The controlled normals therefore fail to expose a large normal-data cost. Saved uncapped models include broad conditions such as hardware concurrency greater than one and language-list length greater than one; satisfying the controlled budget does not constrain these conditions adequately on the MTC material.

**Table 5. Historical-normal outcomes.** T denotes alarm, F definite no alert, and U unknown. Configurations 01 and 02 have equal counts and are displayed together, not pooled. FAILED and EMPTY_MODEL are zero.

| Cohort | N | Configuration | Integrated App: T / F / U | No cap: T / F / U |
| --- | --- | --- | --- | --- |
| Historical development | 144 | 01 / 02 | 1 / 135 / 8 | 144 / 0 / 0 |
| Historical development | 144 | 03 | 0 / 136 / 8 | 144 / 0 / 0 |
| Historically reserved | 117 | 01 / 02 | 1 / 110 / 6 | 117 / 0 / 0 |
| Historically reserved | 117 | 03 | 0 / 111 / 6 | 117 / 0 / 0 |

On the separate 630 training normals, Integrated App configurations 01/02/03 produce 6/6/0 alarms and 51 unknowns each, whereas uncapped models alarm on all 630. These training outcomes are not added to evaluation counts. Within each Integrated App configuration, the two historical evaluation groups have 14/261 unknown outcomes. Removing memory reduces this to 1/261, alongside the resource detection loss. A binary tree output does not recover unavailable measurements: missing candidate states can exist even when the traversed tree path returns a definite label.

## 5.4 RQ4: Increment from a Linked Browser

On the same 60 positions used to choose the extension, adding C1 increases detection from 2/14 to 7/14 (Table 6). The comparison describes the selected extension on that material rather than future paired-data performance. All five added detections are Browser timezone modifications. App timezone detections are preserved; neither language family gains detection. Both methods have 0/46 normal alarms. All three frozen configurations agree in these counts, which are shown once rather than multiplied into 42 modifications.

**Table 6. Paired App–Browser outcomes.** T is detection for modification rows and alarm for the normal row. U and FAILED are zero on this paired material; it has development-use history.

| Record family | N | Integrated App: T | Integrated App + C1: T |
| --- | --- | --- | --- |
| App timezone | 2 | 2 | 2 |
| App language | 2 | 0 | 0 |
| Browser timezone | 5 | 0 | 5 |
| Browser language | 5 | 0 | 0 |
| Normal alarms | 46 | 0 | 0 |

Historical normals expose an availability cost: adding C1 raises unknowns from 8/144 to 11/144 in development and leaves 6/117 in the historically reserved group, or 14/261 (5.4%) to 17/261 (6.5%) within each model. Alarm counts are unchanged. Since C1 has no timestamp gate, the observed 0/46 does not establish robustness to asynchronous legitimate timezone changes. The language recipes here differ from the language-list recipe detected in the App benchmark. The result supports a targeted increment on the tested timezone operations, not a general benefit from more fields.

## 5.5 Synthesis

References help when they contribute usable context that distinguishes a local report from legitimate variation. On the tested records, memory illustrates device-specific context, timezone illustrates legitimate co-change, and geometry illustrates container context beyond same-Web consistency. The historical and paired results then expose the price of admitting checks: normal alarms and inconclusive outputs. Together, these findings support conditional integrity assessment, with detection, normal alarms, and evidence availability reported jointly.
