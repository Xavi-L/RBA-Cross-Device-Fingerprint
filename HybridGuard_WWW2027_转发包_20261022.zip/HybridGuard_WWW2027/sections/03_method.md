# 3 HybridGuard Design

## 3.1 Provenance-Bound Collection

Comparisons require observations tied to the execution they describe. The HybridGuard specification requires field values, collection states, and association context to be preserved under measurement contracts, with source records and receipts for tracing and binding checks. Missing external Browser collection retains an App-only record rather than creating a synthetic Browser vector. Association does not imply atomic sampling or hardware attestation.

Measurement context is part of applicability. In the geometry study, Host snapshots immediately before and after the Web snapshot support a stability check within one collection. These snapshots are not intervention-before and recovery-after records. Experimental phases and restoration records are used to assess the experiment, not to predict the current record. Figure 2 separates this online path from offline detector construction.

![Figure 2. State-aware evaluation and offline construction.](../figures/figure_02_pipeline.png)

**Figure 2.** Selected checks evaluate current, associated observations. An empty selection has its own status. Relevant execution or binding failures take precedence; otherwise any true condition alerts, all false conditions yield no alert, and unresolved cases yield unknown. Offline fitting supplies a frozen model. The gray dash in the schematic denotes U (unknown); the four condition states are T, F, U, and FAILED.

## 3.2 Evidence States and Decision Semantics

Each condition records its operands, source requirements, semantic interpretation, applicability, and trigger. Its output is r_j(x) ∈ {T, F, U, FAILED}. T means an applicable, assessable predicate triggers an alert; F means that this predicate does not trigger, without certifying the report; U means required evidence is missing, insufficient, or outside the domain. FAILED records a relevant execution or association failure. EMPTY_MODEL denotes an empty selection. None of these states is an identity label.

For a nonempty selected set, required-input failures yield FAILED before any trigger is considered. In their absence, any T produces an alert; all F produces a definite no-alert result; every remaining combination produces U. Thus, T can coexist with another condition's U, but cannot override FAILED. Missing unselected fields do not independently fail a detector. Preserving U prevents an unavailable reference from silently becoming evidence of normality.

## 3.3 Semantic References

**Native memory envelope.** For observed, finite, positive memory measurements in GiB from the same bound App record, with m_native ≥ 0.25, the condition is

$$r_{mem}(x)=T \iff m_{web}>2^{\lceil\log_2 m_{native}\rceil}.$$

The Device Memory API draft describes approximate reporting with implementation-defined bounds [13]; that discontinued draft is historical API context, not a guarantee of runtime behavior. The power-of-two envelope is an engineering hypothesis that accommodates coarse reporting and permits lower Web exposure; it is not a guaranteed Android or Web platform invariant. It detects upward violations, not every modification. Within-envelope or coordinated reports can remain compatible. Unusable operands yield U; binding failures yield FAILED. The fixed Web-only comparator tests m_web > 8 GiB. A schematic example is Native memory of 4 GiB and a Web report of 8 GiB: the global check remains false, while the device-specific envelope is violated. The example illustrates the predicate rather than adding an experimental record.

**Native timezone reference.** The Native IANA zone and current collection interval determine the effective UTC offset using the implementation's fixed timezone database, 2026c. Writing o_native(t) for local-minus-UTC minutes at the applicable collection time and o_web for Web getTimezoneOffset, the trigger is o_web ≠ −o_native(t). This conversion follows the Web API's UTC-minus-local sign [14]. Supported fixed-offset identifiers can be checked without a date when consistent with the observed Native standard offset. Different zone names with the same effective offset are compatible. Missing reliable intervals for time-dependent zones, ambiguous transitions, or unusable observations yield U; database or association failures follow the failure policy. Zero and minus one are valid offsets, not missing-value sentinels.

**Host geometry reference (standalone).** The Web interface exposes visual-viewport dimensions in CSS pixels and a separate scale factor [15]. For each axis, P is CSS visual-viewport size multiplied by device-pixel ratio and viewport scale; H_view is the Host View size minus its own padding. The trigger is

$$P>H_{view}+\epsilon,\quad \epsilon=2+4\cdot2^{-23}\max(|P|,|H_{view}|,1)\ \text{pixels}.$$

The condition requires bound snapshots, independently assessed Host stability, finite positive dimensions and scale, an attached visible View, zero padding, and an identity View transform. Outside-domain observations yield U. Stability does not require Host–Web agreement, so a stable contradiction remains assessable. The tolerance is an engineering choice, not a platform guarantee. This condition is outside Integrated App and its candidate pool.

## 3.4 Constrained Construction and Retention

The App pool contains 50 base templates and three fixed relations: Native memory, Native timezone, and same-Web viewport. A template defines a condition over available fields; an atom is its encoded, threshold-instantiated predicate. A literal selects an admitted polarity, and each singleton clause contains one literal. The detector ORs the selected clauses using the state semantics in Section 3.2. Training-only numeric encoding and threshold expansion produce 65/65/56 atoms before admission in configurations 01/02/03. Candidate polarity and assessability are checked before selection. Historical evaluation records do not provide threshold quantiles.

For a set S of singleton-OR clauses, the sparse stage uses

$$J(S)=\frac{1}{14}\sum_{k=1}^{14}d_k(S)-0.005\,C(S).$$

Here k indexes the 14 manipulation recipes, not the three fitted model configurations. For each recipe, d_k averages whole-detector detections over effective modifications within a training environment, then equally across its two training environments. Each environment contributes three effective modification positions per recipe. C(S) counts clauses plus literal occurrences. Thus, with singleton clauses, a selected literal contributes two units of complexity. Greedy improving additions, the best feasible prefix, and backward pruning form a heuristic, not a global optimizer. Limits are eight clauses, complexity 16, two conditions per registered family, and no opposite polarities for one atom. Controlled-normal and historical training-normal alarm budgets are 8/168 and 31/630. Candidate assessability is the fraction of records on which the candidate yields T or F; definite-output coverage is the fraction on which the whole detector yields T or F. Historical candidate assessability and final coverage must each reach 90%; controlled coverage must reach 80% in each pre, modified, and post phase. Fits allow no execution failures and have a 60-second deadline.

Retention starts from each configuration's own sparse solution and preserves existing training detections. Additions extend semantic coverage; same-group swaps use registered higher-quality alternatives and forbid new controlled-normal alarms or lost definite controlled outputs. Proposals must remain feasible. Retention is not further maximization of J. Evaluation uses each saved retention model without selecting a different stage for individual result cells.

## 3.5 Optional Linked Browser

Integrated App + C1 adds a timezone comparison between linked App Web and Browser records. C1 requires observed field status, observed-value quality, and finite numeric non-Boolean operands. It alerts on unequal offsets under the same Web sign convention. Missing operands yield U; invalid association yields FAILED. C1 has no timestamp gate and does not inherit the Native timezone relation's interval handling.

Extension construction considers no addition, C1, language condition C2, and C1+C2 on the frozen App base. Normal-alarm budgets are 31/630, 0/12, and 1/34 for historical training, pilot, and matched normals, with 90% definite outputs per normal group and 90% historical candidate assessability. C2 alarms on two matched normal preference changes; C1+C2 also provides only 566/630 definite historical training outputs. The retained C1 extension is therefore a constrained choice on development-used material, not a new jointly trained classifier or an automatic fallback.
