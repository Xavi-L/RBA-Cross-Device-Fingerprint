# HybridGuard: Cross-Layer Consistency as Integrity Evidence for Android Web Environments

Anonymous Author(s)

## Abstract

Browser-visible environment reports can inform security decisions but can be altered independently of the underlying device. We study whether associated Android Native and WebView Host observations provide conditional integrity evidence for App Web reports. HybridGuard associates observations with an execution, evaluates semantic relations under explicit applicability conditions, and distinguishes true, false, unknown, and failure outcomes. On 126 effective modifications from 14 known recipes in three emulated environments, the integrated App detector identifies 105 modifications, compared with 96 for a separately reconstructed Web-only detector; both raise no alarms on 252 controlled-normal record positions. A refit no-memory alternative also identifies 96 positions; all nine differences occur in the CPU-plus-memory recipe. These refitted comparisons establish component associations within the protocol, not frozen-model causal effects. Exploratory fixed-check comparisons illustrate the mechanisms: the Native memory envelope detects 18/18 tested modifications versus 6/18 for a global threshold, while Native timezone and standalone Host geometry each avoid six normal alarms raised by their absolute comparators. Removing the historical-normal alarm cap gains three controlled detections but alerts on every historical evaluation record. On development-used paired data, a Browser-timezone relation adds five detections while increasing historical unknown outcomes from 14/261 to 17/261 per model. These controlled findings show how contextual references can distinguish selected report edits from legitimate variation, while exposing the accompanying alarm and availability costs. They do not establish attestation or unseen-attack generalization.

**CCS Concepts:** Security and privacy → Web application security; Intrusion/anomaly detection and malware mitigation.

**Keywords:** Android WebView; environment report integrity; cross-layer consistency; fingerprint manipulation; semantic references.
