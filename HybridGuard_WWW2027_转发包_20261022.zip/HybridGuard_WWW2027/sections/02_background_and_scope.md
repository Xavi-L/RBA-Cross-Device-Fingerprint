# 2 Background, Prior Work, and Scope

## 2.1 Fingerprint Consistency and the Remaining Question

Fingerprinting research already uses relationships and behavioral checks to scrutinize reported attributes. FP-Scanner detects inconsistencies introduced by fingerprint countermeasures, including discrepancies across JavaScript and HTTP reports [4]. Picasso compares canvas challenge responses against device-class expectations [5]. FP-Inconsistent studies spatial and temporal inconsistencies in evasive bot traffic [6]. BrowserFM represents dependencies among fingerprints, system characteristics, and browser configurations [7]. Thus, neither inconsistency detection nor structured dependency modeling is new in itself.

WebView research also observes both sides of the application–Web boundary. WVProfiler instruments Android WebViews to study fingerprint exposure [8]; Tracking Without Borders analyzes Java/Kotlin, JavaScript, and runtime behavior to investigate tracking [9]; Cross-Boundary Mobile Tracking studies Java-to-JavaScript information diffusion [10]. Table 1 locates our study among these approaches. Our focus is the compatibility of a current Web report with associated Android device and container measurements, tested against both controlled report edits and legitimate environmental changes. The technical focus is the combination of associated Native or Host references for a current App Web record, predicate-specific applicability and evidence states, and joint accounting of modification coverage, normal alarms, and definite outputs. The table maps this scope rather than establishing comparative performance.

**Table 1. Closely related research and the evidence it examines.** The comparison identifies the study focus rather than claiming absent capabilities or empirical superiority.

| Work | Evidence examined | Research focus | Focus of the present study |
| --- | --- | --- | --- |
| FP-Scanner [4] | Browser attributes; JavaScript/HTTP discrepancies | Countermeasure-induced inconsistencies | Associated Native and Host references |
| Picasso [5] | Canvas challenge responses | Claimed device-class checking | Current-record semantic compatibility |
| FP-Inconsistent [6] | Within-request and temporal inconsistencies | Evasive bot traffic | Controlled edits versus normal changes |
| BrowserFM [7] | Fingerprint/configuration dependencies | Configuration modeling and analysis | Applicability and evidence-availability costs |
| WebView studies [8–10] | App, JavaScript, and runtime observations | Exposure and cross-boundary tracking | Report-integrity assessment |
| HybridGuard | Native, Host, App Web; optional Browser | Contextual references under explicit domains | Detection, normal alarms, and unknown outcomes |


## 2.2 Observation Surfaces and Conditional Compatibility

Let E denote the relevant execution state and container context. The associated observation x = (N(E), H(E), W(E)) contains Native measurements of the system and hardware, WebView Host context, and App Web reports. The App schema contains 177 catalogued fields: 84 Native, 26 Host, and 67 App Web fields. The optional Browser schema contains 67 fields from a separate Web execution; a valid association yields a 244-field paired schema. These are schema-field counts, not independent signals or the number of inputs used by each selected detector.

![Figure 1. Associated observation surfaces and integration boundaries.](../figures/figure_01_surfaces.png)

**Figure 1.** Native–App Web memory and timezone relations are integrated. Host geometry is a separate study. The optional Browser comparison links separate executions. Field counts describe the catalogued schemas; selected checks use a subset. Connectors denote comparisons, not mutual authentication or trusted communication.

A semantic relation C_j constrains a relevant subset of observations within an applicability domain. Local modification can replace W(E) with W′(E) while leaving a distinguishing reference unchanged. A relation violation then supplies evidence of incompatibility. Legitimate changes can instead move related observations together. Neither case requires equality between all fields: different APIs may expose different units, precision, or abstractions. E is explanatory notation, not ground truth supplied to the detector. We call an observed violation conditional report-integrity evidence: within a predicate's stated applicability domain, the jointly observed values violate its declared constraint. This evidence does not identify an altered operand or establish the truth of an individual observation. A trigger becomes a detection in the evaluation only when it occurs on a known effective modification.

## 2.3 Adversary and Claim Boundary

The evaluated attacker surface is the report exposed to the Web application. Controlled browser overrides or emulation alter selected resource, browser, locale, display, and graphics reports while the compared reference can remain unchanged. The intended setting is a cooperating Android application that can obtain Native and Host measurements alongside its embedded webpage; an ordinary remote website cannot obtain these measurements from an arbitrary client without such integration. A measured effect at the target surface is required for an effective modification. The detector receives the current observation, not operation labels, an earlier baseline, or a recovery record. Native and Host measurements can also be manipulated; their position outside a local Web override does not establish administrative or statistical independence.

Our target is evidence about report integrity. An alert does not establish malicious intent, account takeover, or attacker identity, and no alert does not certify authenticity. An adversary can preserve the selected relations, including through coordinated changes. Resistance to collector compromise, backend compromise, or adaptive evasion is not established. This scope separates the use of observations for integrity checking from their use for tracking or device re-identification.
