# 4 Evaluation Protocol

## 4.1 Questions and Materials

We ask four questions: how much controlled App manipulation is detected (RQ1); what semantic references contribute (RQ2); what normal-alarm and availability costs arise (RQ3); and whether a linked Browser adds evidence (RQ4). All rates summarize coverage of recorded benchmark positions, not independent devices or unseen attacks. Table 2 fixes the denominators. The studies have different roles, development histories, and potentially overlapping sources or analysis ranges; we do not sum them into a new sample population or accuracy estimate.

**Table 2. Evaluation materials and their roles.** Counts are record positions, not independent physical devices.

| Material | Effective modifications | Normal records | Evaluation role |
| --- | --- | --- | --- |
| Controlled App | 126 | 252 | 14 configurations × 3 repetitions × 3 environments; disjoint held-out positions |
| MTC discovery | — | 630 | Training-side constraints and tree training |
| MTC historical development | — | 144 | Historical evaluation with development exposure |
| MTC historically reserved | — | 117 | Historical evaluation; not a newly blinded cohort |
| Memory specialist | 18 | 48 | Fixed checks; 6 no-effect operations excluded |
| Timezone specialist | 6 | 30 | Includes 6 normal system changes |
| Geometry specialist | 6 | 66 | Includes 6 normal layout changes; not integrated |
| Paired App–Browser | 14 | 46 | 60 development-used positions: pilot 18 + matched 42 |

The controlled App material covers API 29, 30, and 36 emulator environments with SwiftShader. Fourteen configurations, three repetitions, and three environments yield 126 effective modifications. Each admitted run contributes normal pre- and confirmed post-records, yielding 252 normals. Model identifiers 01, 02, and 03 hold out API 29, 30, and 36, respectively; these three fitted models are distinct from the 14 manipulation recipes. Each uses 84 modified and 168 normal training records, with 42 modified and 84 normal held-out records. The disjoint held-out positions are aggregated once. Development exposure to these environments and recipes prevents interpreting the split as unseen-tool or physical-device attack generalization.

A mobile test-cloud (MTC) representative corresponds to a combination of manufacturer, model, and Android release. They are not 891 independent devices. The 630-record discovery group informs constraints and tree training; the 144- and 117-record historical groups remain separately reported and have development-use history. “Normal” means absence of the study-defined target manipulation, not certified authenticity or absence of debugging and automation.

## 4.2 Compared Methods

Integrated App combines within-view and cross-view checks. Four alternatives rebuild their own sparse and retention stages: removing the MTC alarm cap, retaining only App Web information, removing memory, and removing timezone. Removing the cap relaxes only that alarm budget; other MTC assessability and coverage constraints remain. Web-only changes both available information and constructible relations, so it is not a pure single-factor causal intervention.

The App tree uses the same fold-specific admitted candidate-state representation, encoded by T/F/U indicators. It has depth three, minimum leaf size two, and Gini splitting. Training assigns half the weight to modifications, one quarter to controlled normals, and one quarter to MTC normals; modification weight is balanced across configurations. This is a fixed representation/capacity comparator, not an exhaustive evaluation of machine learning on raw fields. The tree uses saved fitted outputs; rule models use saved retention outputs. Specialist checks and Integrated App + C1 retain their separate identities.

## 4.3 Measures and Aggregate Reconciliation

A detection is T on an effective modification; a normal alarm is T on a normal record. We separately retain F, U, FAILED, and EMPTY_MODEL. Unknowns remain in their denominators and count as neither definite normal decisions nor successful detections. Repeated configurations do not create additional records; equal counts do not prove equal record-level predictions. We report descriptive counts without significance tests or population estimates.

The artifact contains aggregate state counts, recipe identifiers, and mappings to saved experiment summaries. Arithmetic checks verify state partitions and agreement between per-recipe counts and reported totals. These checks do not independently establish the correctness of labels or collection bindings. Raw payloads, collection logs, pairing tickets, and the complete detector implementation are not part of this artifact, limiting independent reconstruction of per-record effects and temporal associations.
