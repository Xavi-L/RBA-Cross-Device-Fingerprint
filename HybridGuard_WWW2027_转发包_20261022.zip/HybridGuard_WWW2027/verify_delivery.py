"""Audit saved aggregates and manuscript links. Does not rerun experiments."""
from pathlib import Path
import csv, re, json, hashlib
root=Path(__file__).resolve().parent
data={p.name[:2]:list(csv.DictReader(p.open(encoding='utf-8-sig',newline=''))) for p in (root/'data').glob('*.csv')}
assert len(data)==9
assert sum(map(len,data.values()))==236
for r in data['01']:
    assert int(r['修改N'])==sum(int(r[k]) for k in ['检出T','漏检F','未知U','失败','空模型'])
    assert int(r['正常N'])==sum(int(r[k]) for k in ['报警T','未报F','未知U_正常','失败_正常','空模型_正常'])
    detail=[x for x in data['02'] if x['方法ID']==r['方法ID']]
    assert len(detail)==14 and sum(int(x['T']) for x in detail)==int(r['检出T'])
for key in ['02','03','05','06']:
    for r in data[key]:
        assert int(r['N'])==sum(int(r.get(k,0)) for k in ['T','F','U','FAILED','EMPTY_MODEL'])
for r in data['04']:
    assert int(r['修改N'])==sum(int(r[k]) for k in ['检出T','漏检F','未知U','失败'])
    assert int(r['正常N'])==sum(int(r[k]) for k in ['报警T','未报F','未知U_正常','失败_正常'])
for r in data['07']:
    assert int(r['总N'])==int(r['修改N'])+int(r['正常N'])
    assert int(r['修改N'])==sum(int(r[k]) for k in ['检出T','漏检F','修改U','修改FAILED'])
    assert int(r['正常N'])==sum(int(r[k]) for k in ['报警T','未报F','正常U','正常FAILED'])
for conf in ['01','02','03']:
    for model,expected in [('APP_FULL',2),('PAIRED_BASE',7)]:
        rows=[r for r in data['05'] if r['模型配置']==conf and r['方法ID']==model and r['记录角色']=='EFFECTIVE_INTERVENTION']
        assert sum(int(r['N']) for r in rows)==14 and sum(int(r['T']) for r in rows)==expected
    for method,expected in [('完整App',14),('完整App加C1',17)]:
        assert sum(int(r['U']) for r in data['06'] if r['模型配置']==conf and r['方法']==method)==expected
for f in (root/'sections').glob('*.md'):
    txt=f.read_text(encoding='utf-8')
    assert not any(x in txt for x in ['{{TABLE','TODO','TBD','[citation needed]'])
    for link in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',txt): assert (f.parent/link).is_file(), link
full=(root/'HybridGuard_full_draft.md').read_text(encoding='utf-8')
expected='\n\n'.join(p.read_text(encoding='utf-8').strip() for p in sorted((root/'sections').glob('*.md'))).replace('../figures/','figures/')
assert re.sub(r'\s+',' ',full).strip()==re.sub(r'\s+',' ',expected).strip()
for n in range(1,7):
    assert f'**Table {n}.' in full
    assert (root/'tables'/f'table_{n:02d}.md').read_text(encoding='utf-8').strip() in full
assert len(list((root/'figures').glob('*.png')))==3
if (root/'notes/delivery_hashes.json').exists():
    for rel,digest in json.loads((root/'notes/delivery_hashes.json').read_text(encoding='utf-8')).items():
        assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,rel
print('PASS: 9 CSVs / 236 rows; state partitions; App 84-cell reconciliation; paired increments; image and table links; merged manuscript; file hashes.')
print('Scope: presentation and aggregate consistency only; no raw-record validation or detector rerun.')
