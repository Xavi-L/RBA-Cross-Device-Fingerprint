# MTC 正常约束下的规则重新选择

本轮已完成固定两方案、三个环境留一折的训练和评价。这是已有数据上的分组开发评估；历史 reserved_validation 名称不表示新的独立盲测。

上一轮另列的 11 条整层缺失记录和 6 条同 session 额外观测本轮不新增训练或预测，去向仍见上一轮报告；本轮固定比较 891 主代表、137 配对重复及 654 App-only。

- **A 完整候选池**：受控攻击检出 114/126（90.48%）；三个模型的 MTC 结果分别见下表，不选择最好一折。
- **B 历史 MTC 兼容候选模型**：受控攻击检出 96/126（76.19%）；三个模型的 MTC 结果分别见下表，不选择最好一折。

A 保留完整 50 项基础候选及原有数值展开；B 是历史 MTC 兼容候选模型，候选在 MTC 训练部分的 T/F 可评估比例和最终模型明确输出覆盖都要求至少 90%。两方案各折编码器只由本折受控训练记录生成，MTC 不生成阈值。

两个正常集合分别执行 floor(记录数 × 5%) 的 OR 集合报警预算，不能合并分母。每折受控正常 168 条允许 8 条、MTC discovery 630 条允许 31 条。5% 是固定开发操作点，不是部署标准，也不保证评价集达到它。容量上限 8 条、复杂度 16；每方案从新 GREEDY 开始再运行 R_KEEP。

保存预测包含 378 条不重复受控记录、1682 条不重复 MTC 记录、906 个 MTC 厂商／型号／系统组合。MTC 同一记录被三个模型计算，不增加独立样本量；下表逐模型列出。

## 受控数据的相同成员对照

三折留出受控记录互不重复，允许合并；未知、失败和空模型均在分母内。

| 方案 | 攻击检出 | 配对正常报警 | 明确输出覆盖 | 明确不报警 | U | FAILED | EMPTY_MODEL |
|---|---|---|---|---:|---:|---:|---:|
| 原 CAP8 | 126/126（100.00%） | 0/252（0.00%） | 378/378（100.00%） | 252 | 0 | 0 | 0 |
| A 完整候选池 | 114/126（90.48%） | 0/252（0.00%） | 378/378（100.00%） | 264 | 0 | 0 | 0 |
| B 历史 MTC 兼容候选模型 | 96/126（76.19%） | 0/252（0.00%） | 378/378（100.00%） | 282 | 0 | 0 | 0 |

| 攻击配置 | 原 CAP8 | A 完整候选池 | B 历史 MTC 兼容候选模型 |
|---|---|---|---|
| w10-cdp-emulation-screen-metrics-only-v1 | 9/9（100.00%） | 6/9（66.67%） | 6/9（66.67%） |
| w10-cdp-emulation-timezone-only-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w6-tool-054-legacy-default-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w6-tool-055-legacy-default-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w6-tool-056-legacy-default-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w6-tool-058-legacy-default-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w9-rule-boundary-cdp-platform-only-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w9-rule-boundary-cdp-resource-pair-v1 | 9/9（100.00%） | 0/9（0.00%） | 0/9（0.00%） |
| w9-rule-boundary-cdp-ua-only-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w9-rule-boundary-cdp-ua-platform-desktop-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w9-rule-boundary-cdp-webdriver-only-v1 | 9/9（100.00%） | 9/9（100.00%） | 0/9（0.00%） |
| w9-stealth-boundary-languages-only-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w9-stealth-boundary-plugins-mime-v1 | 9/9（100.00%） | 9/9（100.00%） | 9/9（100.00%） |
| w9-stealth-boundary-webgl-pair-v1 | 9/9（100.00%） | 9/9（100.00%） | 0/9（0.00%） |

## MTC：逐模型、逐子集

每格保留各自完整分母。报警为已经观察到的触发；U 不能算正常通过，EMPTY_MODEL 不能算可用检测器。正常采集依据沿用上一轮 DATA_NOTES.md 的任务和批次记录；无依据记录仅计算报警比例，不回写历史标签。

| 方案 | 折 | 子集 | 预定/处理 | 报警 | 明确不报警 | U | FAILED | EMPTY_MODEL | 明确输出覆盖 | 有正常依据的报警比例 |
|---|---|---|---|---:|---:|---:|---:|---:|---|---|
| BASELINE | 01 | discovery（训练） | 630/630 | 597 | 0 | 33 | 0 | 0 | 597/630（94.76%） | 597/630（94.76%） |
| BASELINE | 01 | development（评价） | 144/144 | 135 | 0 | 9 | 0 | 0 | 135/144（93.75%） | 135/144（93.75%） |
| BASELINE | 01 | reserved_validation（评价） | 117/117 | 112 | 0 | 5 | 0 | 0 | 112/117（95.73%） | 112/117（95.73%） |
| BASELINE | 01 | 配对重复（补充） | 137/137 | 127 | 0 | 10 | 0 | 0 | 127/137（92.70%） | 127/137（92.70%） |
| BASELINE | 01 | App-only（补充） | 654/654 | 607 | 0 | 47 | 0 | 0 | 607/654（92.81%） | 607/654（92.81%） |
| BASELINE | 02 | discovery（训练） | 630/630 | 597 | 0 | 33 | 0 | 0 | 597/630（94.76%） | 597/630（94.76%） |
| BASELINE | 02 | development（评价） | 144/144 | 135 | 0 | 9 | 0 | 0 | 135/144（93.75%） | 135/144（93.75%） |
| BASELINE | 02 | reserved_validation（评价） | 117/117 | 112 | 0 | 5 | 0 | 0 | 112/117（95.73%） | 112/117（95.73%） |
| BASELINE | 02 | 配对重复（补充） | 137/137 | 127 | 0 | 10 | 0 | 0 | 127/137（92.70%） | 127/137（92.70%） |
| BASELINE | 02 | App-only（补充） | 654/654 | 607 | 0 | 47 | 0 | 0 | 607/654（92.81%） | 607/654（92.81%） |
| BASELINE | 03 | discovery（训练） | 630/630 | 597 | 0 | 33 | 0 | 0 | 597/630（94.76%） | 597/630（94.76%） |
| BASELINE | 03 | development（评价） | 144/144 | 135 | 0 | 9 | 0 | 0 | 135/144（93.75%） | 135/144（93.75%） |
| BASELINE | 03 | reserved_validation（评价） | 117/117 | 112 | 0 | 5 | 0 | 0 | 112/117（95.73%） | 112/117（95.73%） |
| BASELINE | 03 | 配对重复（补充） | 137/137 | 127 | 0 | 10 | 0 | 0 | 127/137（92.70%） | 127/137（92.70%） |
| BASELINE | 03 | App-only（补充） | 654/654 | 607 | 0 | 47 | 0 | 0 | 607/654（92.81%） | 607/654（92.81%） |
| A | 01 | discovery（训练） | 630/630 | 8 | 0 | 622 | 0 | 0 | 8/630（1.27%） | 8/630（1.27%） |
| A | 01 | development（评价） | 144/144 | 1 | 0 | 143 | 0 | 0 | 1/144（0.69%） | 1/144（0.69%） |
| A | 01 | reserved_validation（评价） | 117/117 | 2 | 0 | 115 | 0 | 0 | 2/117（1.71%） | 2/117（1.71%） |
| A | 01 | 配对重复（补充） | 137/137 | 1 | 0 | 136 | 0 | 0 | 1/137（0.73%） | 1/137（0.73%） |
| A | 01 | App-only（补充） | 654/654 | 4 | 0 | 650 | 0 | 0 | 4/654（0.61%） | 4/654（0.61%） |
| A | 02 | discovery（训练） | 630/630 | 8 | 0 | 622 | 0 | 0 | 8/630（1.27%） | 8/630（1.27%） |
| A | 02 | development（评价） | 144/144 | 1 | 0 | 143 | 0 | 0 | 1/144（0.69%） | 1/144（0.69%） |
| A | 02 | reserved_validation（评价） | 117/117 | 2 | 0 | 115 | 0 | 0 | 2/117（1.71%） | 2/117（1.71%） |
| A | 02 | 配对重复（补充） | 137/137 | 1 | 0 | 136 | 0 | 0 | 1/137（0.73%） | 1/137（0.73%） |
| A | 02 | App-only（补充） | 654/654 | 4 | 0 | 650 | 0 | 0 | 4/654（0.61%） | 4/654（0.61%） |
| A | 03 | discovery（训练） | 630/630 | 2 | 0 | 628 | 0 | 0 | 2/630（0.32%） | 2/630（0.32%） |
| A | 03 | development（评价） | 144/144 | 0 | 0 | 144 | 0 | 0 | 0/144（0.00%） | 0/144（0.00%） |
| A | 03 | reserved_validation（评价） | 117/117 | 1 | 0 | 116 | 0 | 0 | 1/117（0.85%） | 1/117（0.85%） |
| A | 03 | 配对重复（补充） | 137/137 | 1 | 0 | 136 | 0 | 0 | 1/137（0.73%） | 1/137（0.73%） |
| A | 03 | App-only（补充） | 654/654 | 0 | 0 | 654 | 0 | 0 | 0/654（0.00%） | 0/654（0.00%） |
| B | 01 | discovery（训练） | 630/630 | 8 | 619 | 3 | 0 | 0 | 627/630（99.52%） | 8/630（1.27%） |
| B | 01 | development（评价） | 144/144 | 1 | 142 | 1 | 0 | 0 | 143/144（99.31%） | 1/144（0.69%） |
| B | 01 | reserved_validation（评价） | 117/117 | 2 | 115 | 0 | 0 | 0 | 117/117（100.00%） | 2/117（1.71%） |
| B | 01 | 配对重复（补充） | 137/137 | 1 | 136 | 0 | 0 | 0 | 137/137（100.00%） | 1/137（0.73%） |
| B | 01 | App-only（补充） | 654/654 | 4 | 626 | 24 | 0 | 0 | 630/654（96.33%） | 4/654（0.61%） |
| B | 02 | discovery（训练） | 630/630 | 8 | 619 | 3 | 0 | 0 | 627/630（99.52%） | 8/630（1.27%） |
| B | 02 | development（评价） | 144/144 | 1 | 142 | 1 | 0 | 0 | 143/144（99.31%） | 1/144（0.69%） |
| B | 02 | reserved_validation（评价） | 117/117 | 2 | 115 | 0 | 0 | 0 | 117/117（100.00%） | 2/117（1.71%） |
| B | 02 | 配对重复（补充） | 137/137 | 1 | 136 | 0 | 0 | 0 | 137/137（100.00%） | 1/137（0.73%） |
| B | 02 | App-only（补充） | 654/654 | 4 | 626 | 24 | 0 | 0 | 630/654（96.33%） | 4/654（0.61%） |
| B | 03 | discovery（训练） | 630/630 | 2 | 625 | 3 | 0 | 0 | 627/630（99.52%） | 2/630（0.32%） |
| B | 03 | development（评价） | 144/144 | 0 | 143 | 1 | 0 | 0 | 143/144（99.31%） | 0/144（0.00%） |
| B | 03 | reserved_validation（评价） | 117/117 | 1 | 116 | 0 | 0 | 0 | 117/117（100.00%） | 1/117（0.85%） |
| B | 03 | 配对重复（补充） | 137/137 | 1 | 136 | 0 | 0 | 0 | 137/137（100.00%） | 1/137（0.73%） |
| B | 03 | App-only（补充） | 654/654 | 0 | 630 | 24 | 0 | 0 | 630/654（96.33%） | 0/654（0.00%） |

与原模型的变化均用同一折、同一子集比较：

- A / 01：主代表合计 891 条，报警变化 -833，明确不报警变化 +0，U 变化 +833。分割用途保持独立，上面的逐子集结果才是训练与评价比较依据。
- A / 02：主代表合计 891 条，报警变化 -833，明确不报警变化 +0，U 变化 +833。分割用途保持独立，上面的逐子集结果才是训练与评价比较依据。
- A / 03：主代表合计 891 条，报警变化 -841，明确不报警变化 +0，U 变化 +841。分割用途保持独立，上面的逐子集结果才是训练与评价比较依据。
- B / 01：主代表合计 891 条，报警变化 -833，明确不报警变化 +876，U 变化 -43。分割用途保持独立，上面的逐子集结果才是训练与评价比较依据。
- B / 02：主代表合计 891 条，报警变化 -833，明确不报警变化 +876，U 变化 -43。分割用途保持独立，上面的逐子集结果才是训练与评价比较依据。
- B / 03：主代表合计 891 条，报警变化 -841，明确不报警变化 +884，U 变化 -43。分割用途保持独立，上面的逐子集结果才是训练与评价比较依据。

至少一部分新模型的未知多于明确不报警：只能称观察到的报警减少，完整判断仍受限，不能直接宣称已成为低误报可用模型。

## 选中了什么，淘汰依据是什么

候选统计只使用各折受控训练数据和 MTC discovery；攻击支持、配置覆盖、轨迹从不包含 MTC。完整逐候选统计、集合分数和操作轨迹保存在各 trial/training.json。以下新模型均为 R_KEEP 最终结果。

- A / 折 01,02：移除 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE; CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE`；新增 `CONTROL:app.web_data.screen_layer.inner_height:LE:710.0:NEGATIVE`。
- A / 折 03：移除 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE; CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE`；新增 `无`。
- B / 折 01,02：移除 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE; CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE; RSR-WEBDRIVER-STATE-v1:POSITIVE; RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE`；新增 `CONTROL:app.web_data.screen_layer.inner_height:LE:710.0:NEGATIVE`。
- B / 折 03：移除 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE; CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE; RSR-WEBDRIVER-STATE-v1:POSITIVE; RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE`；新增 `无`。
### A / 01

模型 `mtc-reselection-eb5b1cf4c2543330d997747e`；状态 `FITTED`；规则数 7。

- `{"literals": [{"atom_id": "RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.automation_surface_layer.mime_types_count:LE:0.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-WEBDRIVER-STATE-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.execution_layer.timezone_offset:LE:-480.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-LANG-FIRST-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CAT:NW-006", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.screen_layer.inner_height:LE:710.0", "polarity": "NEGATIVE"}]}`

展开 literal 124 个，准入 93 个。准入原因计数（可重叠）`{"INSUFFICIENT_TRAIN_SUPPORT": 31}`；单条集合预算拒绝计数（可重叠）`{"CONTROLLED_SET_NORMAL_BUDGET": 75, "MTC_SET_NORMAL_BUDGET": 77}`。

入选但 MTC 训练完全不可评估的条件：`RSR-WEBDRIVER-STATE-v1:POSITIVE`、`RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE`。这里的 0 次观察触发不能写成条件误报率为 0。
### B / 01

模型 `mtc-reselection-a92e6c31201dd607f808f380`；状态 `FITTED`；规则数 5。

- `{"literals": [{"atom_id": "CONTROL:app.web_data.automation_surface_layer.mime_types_count:LE:0.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.execution_layer.timezone_offset:LE:-480.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-LANG-FIRST-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CAT:NW-006", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.screen_layer.inner_height:LE:710.0", "polarity": "NEGATIVE"}]}`

展开 literal 124 个，准入 89 个。准入原因计数（可重叠）`{"INSUFFICIENT_TRAIN_SUPPORT": 31, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 4}`；单条集合预算拒绝计数（可重叠）`{"CONTROLLED_SET_NORMAL_BUDGET": 75, "MTC_SET_NORMAL_BUDGET": 77}`。
### A / 02

模型 `mtc-reselection-226b3ed2088edc97b5c50406`；状态 `FITTED`；规则数 7。

- `{"literals": [{"atom_id": "RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.automation_surface_layer.mime_types_count:LE:0.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-WEBDRIVER-STATE-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.execution_layer.timezone_offset:LE:-480.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-LANG-FIRST-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CAT:NW-006", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.screen_layer.inner_height:LE:710.0", "polarity": "NEGATIVE"}]}`

展开 literal 124 个，准入 93 个。准入原因计数（可重叠）`{"INSUFFICIENT_TRAIN_SUPPORT": 31}`；单条集合预算拒绝计数（可重叠）`{"CONTROLLED_SET_NORMAL_BUDGET": 75, "MTC_SET_NORMAL_BUDGET": 77}`。

入选但 MTC 训练完全不可评估的条件：`RSR-WEBDRIVER-STATE-v1:POSITIVE`、`RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE`。这里的 0 次观察触发不能写成条件误报率为 0。
### B / 02

模型 `mtc-reselection-888dcb1a9d06a5d4bac23288`；状态 `FITTED`；规则数 5。

- `{"literals": [{"atom_id": "CONTROL:app.web_data.automation_surface_layer.mime_types_count:LE:0.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.execution_layer.timezone_offset:LE:-480.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-LANG-FIRST-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CAT:NW-006", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.screen_layer.inner_height:LE:710.0", "polarity": "NEGATIVE"}]}`

展开 literal 124 个，准入 89 个。准入原因计数（可重叠）`{"INSUFFICIENT_TRAIN_SUPPORT": 31, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 4}`；单条集合预算拒绝计数（可重叠）`{"CONTROLLED_SET_NORMAL_BUDGET": 75, "MTC_SET_NORMAL_BUDGET": 77}`。
### A / 03

模型 `mtc-reselection-9794faa9433752b1ae28ca2e`；状态 `FITTED`；规则数 6。

- `{"literals": [{"atom_id": "RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.automation_surface_layer.mime_types_count:LE:0.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-WEBDRIVER-STATE-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.execution_layer.timezone_offset:LE:-480.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-LANG-FIRST-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CAT:NW-006", "polarity": "POSITIVE"}]}`

展开 literal 106 个，准入 74 个。准入原因计数（可重叠）`{"INSUFFICIENT_TRAIN_SUPPORT": 32}`；单条集合预算拒绝计数（可重叠）`{"CONTROLLED_SET_NORMAL_BUDGET": 56, "MTC_SET_NORMAL_BUDGET": 64}`。

入选但 MTC 训练完全不可评估的条件：`RSR-WEBDRIVER-STATE-v1:POSITIVE`、`RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE`。这里的 0 次观察触发不能写成条件误报率为 0。
### B / 03

模型 `mtc-reselection-491c594bb07dcffce2854acd`；状态 `FITTED`；规则数 4。

- `{"literals": [{"atom_id": "CONTROL:app.web_data.automation_surface_layer.mime_types_count:LE:0.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "CONTROL:app.web_data.execution_layer.timezone_offset:LE:-480.0", "polarity": "NEGATIVE"}]}`
- `{"literals": [{"atom_id": "RSR-LANG-FIRST-v1", "polarity": "POSITIVE"}]}`
- `{"literals": [{"atom_id": "CAT:NW-006", "polarity": "POSITIVE"}]}`

展开 literal 106 个，准入 70 个。准入原因计数（可重叠）`{"INSUFFICIENT_TRAIN_SUPPORT": 32, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 4}`；单条集合预算拒绝计数（可重叠）`{"CONTROLLED_SET_NORMAL_BUDGET": 56, "MTC_SET_NORMAL_BUDGET": 64}`。

## 新漏检与替代条件

下面先用留出实际结果定位新漏检，再用已保存训练候选统计解释。单条在训练中可行不代表可与其他规则组成可行 OR 模型，也不保证留出集检出；启发式未找到组合不等于理论不可能。

| 方案/折 | 新漏检配置 | 条数 | 原检出条件 | 有训练触发的候选数 | 单条通过准入和正常预算的候选数 |
|---|---|---:|---|---:|---:|
| A/01 | w9-rule-boundary-cdp-resource-pair-v1 | 3 | CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE | 75 | 0 |
| A/02 | w9-rule-boundary-cdp-resource-pair-v1 | 3 | CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE | 75 | 0 |
| A/03 | w10-cdp-emulation-screen-metrics-only-v1 | 3 | CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE | 56 | 0 |
| A/03 | w9-rule-boundary-cdp-resource-pair-v1 | 3 | CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE | 56 | 0 |
| B/01 | w9-rule-boundary-cdp-resource-pair-v1 | 3 | CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE | 75 | 0 |
| B/01 | w9-rule-boundary-cdp-webdriver-only-v1 | 3 | RSR-WEBDRIVER-STATE-v1:POSITIVE | 75 | 0 |
| B/01 | w9-stealth-boundary-webgl-pair-v1 | 3 | RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE | 74 | 0 |
| B/02 | w9-rule-boundary-cdp-resource-pair-v1 | 3 | CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE | 75 | 0 |
| B/02 | w9-rule-boundary-cdp-webdriver-only-v1 | 3 | RSR-WEBDRIVER-STATE-v1:POSITIVE | 74 | 0 |
| B/02 | w9-stealth-boundary-webgl-pair-v1 | 3 | RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE | 74 | 0 |
| B/03 | w10-cdp-emulation-screen-metrics-only-v1 | 3 | CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE | 56 | 0 |
| B/03 | w9-rule-boundary-cdp-resource-pair-v1 | 3 | CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE | 56 | 0 |
| B/03 | w9-rule-boundary-cdp-webdriver-only-v1 | 3 | RSR-WEBDRIVER-STATE-v1:POSITIVE | 56 | 0 |
| B/03 | w9-stealth-boundary-webgl-pair-v1 | 3 | RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE | 55 | 0 |

- A/01 w9-rule-boundary-cdp-resource-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 73, "MTC_SET_NORMAL_BUDGET": 69}。

  训练结束后的只读候选诊断中，有 63 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 60, "MTC_SET_NORMAL_BUDGET": 57, "INSUFFICIENT_TRAIN_SUPPORT": 1}`。

  原条件 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE` 的训练正常触发：受控 0/168，MTC 554/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- A/02 w9-rule-boundary-cdp-resource-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 73, "MTC_SET_NORMAL_BUDGET": 69}。

  训练结束后的只读候选诊断中，有 62 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 60, "MTC_SET_NORMAL_BUDGET": 56}`。

  原条件 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE` 的训练正常触发：受控 0/168，MTC 554/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- A/03 w10-cdp-emulation-screen-metrics-only-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 52, "MTC_SET_NORMAL_BUDGET": 49}。

  训练结束后的只读候选诊断中，有 54 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 48, "MTC_SET_NORMAL_BUDGET": 48, "INSUFFICIENT_TRAIN_SUPPORT": 2}`。

  原条件 `CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE` 的训练正常触发：受控 0/168，MTC 518/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- A/03 w9-rule-boundary-cdp-resource-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 54, "MTC_SET_NORMAL_BUDGET": 51}。

  训练结束后的只读候选诊断中，有 54 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 47, "MTC_SET_NORMAL_BUDGET": 50, "INSUFFICIENT_TRAIN_SUPPORT": 2}`。

  原条件 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE` 的训练正常触发：受控 0/168，MTC 554/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- B/01 w9-rule-boundary-cdp-resource-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 73, "MTC_SET_NORMAL_BUDGET": 69, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 63 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 60, "MTC_SET_NORMAL_BUDGET": 57, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2, "INSUFFICIENT_TRAIN_SUPPORT": 1}`。

  原条件 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE` 的训练正常触发：受控 0/168，MTC 554/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- B/01 w9-rule-boundary-cdp-webdriver-only-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 74, "MTC_SET_NORMAL_BUDGET": 67, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 62 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 60, "MTC_SET_NORMAL_BUDGET": 54, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2, "INSUFFICIENT_TRAIN_SUPPORT": 1}`。

  原条件 `RSR-WEBDRIVER-STATE-v1:POSITIVE` 的训练正常触发：受控 0/168，MTC 0/630；未入选原因 `MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT`。

- B/01 w9-stealth-boundary-webgl-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 73, "MTC_SET_NORMAL_BUDGET": 66, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 62 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 60, "MTC_SET_NORMAL_BUDGET": 54, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2, "INSUFFICIENT_TRAIN_SUPPORT": 1}`。

  原条件 `RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE` 的训练正常触发：受控 0/168，MTC 0/630；未入选原因 `MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT`。

- B/02 w9-rule-boundary-cdp-resource-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 73, "MTC_SET_NORMAL_BUDGET": 69, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 62 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 60, "MTC_SET_NORMAL_BUDGET": 56, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}`。

  原条件 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE` 的训练正常触发：受控 0/168，MTC 554/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- B/02 w9-rule-boundary-cdp-webdriver-only-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 73, "MTC_SET_NORMAL_BUDGET": 66, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 63 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 62, "MTC_SET_NORMAL_BUDGET": 55, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}`。

  原条件 `RSR-WEBDRIVER-STATE-v1:POSITIVE` 的训练正常触发：受控 0/168，MTC 0/630；未入选原因 `MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT`。

- B/02 w9-stealth-boundary-webgl-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 73, "MTC_SET_NORMAL_BUDGET": 66, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 62 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 61, "MTC_SET_NORMAL_BUDGET": 54, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}`。

  原条件 `RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE` 的训练正常触发：受控 0/168，MTC 0/630；未入选原因 `MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT`。

- B/03 w10-cdp-emulation-screen-metrics-only-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 52, "MTC_SET_NORMAL_BUDGET": 49, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 54 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 48, "MTC_SET_NORMAL_BUDGET": 48, "INSUFFICIENT_TRAIN_SUPPORT": 2, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}`。

  原条件 `CONTROL:app.web_data.screen_layer.device_pixel_ratio:LE:2.625:NEGATIVE` 的训练正常触发：受控 0/168，MTC 518/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- B/03 w9-rule-boundary-cdp-resource-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 54, "MTC_SET_NORMAL_BUDGET": 51, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 54 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 47, "MTC_SET_NORMAL_BUDGET": 50, "INSUFFICIENT_TRAIN_SUPPORT": 2, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}`。

  原条件 `CONTROL:app.web_data.navigator_layer.device_memory:LE:2.0:NEGATIVE` 的训练正常触发：受控 0/168，MTC 554/630；未入选原因 `MTC_SET_NORMAL_BUDGET`。

- B/03 w9-rule-boundary-cdp-webdriver-only-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 55, "MTC_SET_NORMAL_BUDGET": 49, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 53 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 47, "MTC_SET_NORMAL_BUDGET": 47, "INSUFFICIENT_TRAIN_SUPPORT": 2, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}`。

  原条件 `RSR-WEBDRIVER-STATE-v1:POSITIVE` 的训练正常触发：受控 0/168，MTC 0/630；未入选原因 `MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT`。

- B/03 w9-stealth-boundary-webgl-pair-v1：本折有训练触发的候选均未通过保存的准入或单条正常预算检查；这是当前候选与固定设置的有限结论。拒绝原因（可重叠）：{"CONTROLLED_SET_NORMAL_BUDGET": 54, "MTC_SET_NORMAL_BUDGET": 48, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}。

  训练结束后的只读候选诊断中，有 53 个 literal 实际触发留出攻击，但均未通过训练准入或单条正常预算。原因计数（可重叠）：`{"CONTROLLED_SET_NORMAL_BUDGET": 47, "MTC_SET_NORMAL_BUDGET": 47, "INSUFFICIENT_TRAIN_SUPPORT": 2, "MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT": 2}`。

  原条件 `RSR-WEBGL1-PARAMETER-EQUIVALENCE-v1:POSITIVE` 的训练正常触发：受控 0/168，MTC 0/630；未入选原因 `MTC_CANDIDATE_EVALUABILITY_BELOW_90_PERCENT`。

训练完成后核对的实际数值重叠示例（正常侧取 discovery；只用于解释，不影响已保存模型）：

- `{"attack_sample_id": "webgl1fresh-19087ce2-c09a-4725-87dc-df392437d0d9", "configuration_id": "w6-tool-055-legacy-default-v1", "field": "app.web_data.navigator_layer.device_memory", "fold_id": "WEBGL1-LOEO-v1-01", "normal_profile": {"android_api": 36, "android_release": "16", "collector_install_id": "5afbd3fe-6ec7-4cee-a870-17b70f06a9a6", "manufacturer": "Xiaomi", "model": "23113RKC6C"}, "normal_sample_id": "mtc-pair-hgpair-v1-006a72c18d9adf2f7fc3db9b", "normal_source_line": 455, "note": "same reported field value, not evidence of equal physical hardware", "value": 8.0}`
- `{"attack_sample_id": "webgl1fresh-3b301b2c-e1d7-4a29-9faf-fc3826a14909", "configuration_id": "w6-tool-054-legacy-default-v1", "field": "app.web_data.navigator_layer.device_memory", "fold_id": "WEBGL1-LOEO-v1-02", "normal_profile": {"android_api": 36, "android_release": "16", "collector_install_id": "5afbd3fe-6ec7-4cee-a870-17b70f06a9a6", "manufacturer": "Xiaomi", "model": "23113RKC6C"}, "normal_sample_id": "mtc-pair-hgpair-v1-006a72c18d9adf2f7fc3db9b", "normal_source_line": 455, "note": "same reported field value, not evidence of equal physical hardware", "value": 8.0}`
- `{"attack_sample_id": "webgl1fresh-26b92dcb-b425-49c1-91c2-5a11cebd016b", "configuration_id": "w6-tool-054-legacy-default-v1", "field": "app.web_data.navigator_layer.device_memory", "fold_id": "WEBGL1-LOEO-v1-03", "normal_profile": {"android_api": 36, "android_release": "16", "collector_install_id": "5afbd3fe-6ec7-4cee-a870-17b70f06a9a6", "manufacturer": "Xiaomi", "model": "23113RKC6C"}, "normal_sample_id": "mtc-pair-hgpair-v1-006a72c18d9adf2f7fc3db9b", "normal_source_line": 455, "note": "same reported field value, not evidence of equal physical hardware", "value": 8.0}`

完整原值和样本引用见 OVERLAP_EXAMPLES.json。相同暴露值可同时出现在正常设备和干预记录中，单一绝对阈值不能由这些值本身区分来源。

## 旧观测限制和下一步

旧 MTC 没有 WebGL1 数字／数字字符串查询原始观测，webdriver false 投影不能恢复属性存在与读取状态；这些条件保留 U。旧 deviceMemory / hardwareConcurrency 默认 0 按哨兵处理，不能当作真实零值。来源、标签、型号、任务 ID 和历史 split 只作关联，不进入预测。

训练正常反例若让原高内存／高 DPR 条件超出独立预算，说明单一绝对阈值把合法设备范围和攻击值混在一起；本轮由同一通用预算机制淘汰，不手工封禁字段名。替代条件是否有支持、是否可观测和是否超出预算分别保存在候选统计与 new_misses 中。

下一步优先处理新漏检配置中正常与攻击数值范围重叠的问题：先核对候选是否具有可解释的适用域或关系证据，再提出一个有针对性的候选修订。不能把 Web 内存和 Native 物理内存强设为相等。对于仍依赖未知条件的方案，最小补采是同次 App 主 frame 的 WebGL1 原始查询和 webdriver 属性存在／读取状态／类型；补采用于验证正常侧表现，不能通过填 F 修饰当前结果。本轮没有实施新规则、追加拟合或启动采集。

## 运行记录和复现

执行摘要：`{"actual_fit_calls": 12, "all_fits_closed": true, "all_models_frozen_at": "2026-10-02T10:32:00.813547+00:00", "elapsed_seconds": 5.420022208003502, "encoder_fit_calls": 3, "encoder_source": "controlled_train_only_shared_per_fold", "engineering_corrections": [], "experiment_id": "mtc-constrained-reselection-v1", "fit_status_counts": {"FITTED": 12}, "mtc_evaluation_ids_used_for_fit": [], "new_evaluation_opened_during_training": false, "planned_fit_calls": 12}`。逐次拟合记录与完整训练成员见 EXECUTION.json。

```bash
# 仅从本轮保存的预测、训练统计和清单重建报告；不加载原数据，不训练、不预测
python3 deliverables/mtc_constrained_reselection_v1/summarize.py --output-dir deliverables/mtc_constrained_reselection_v1
```

`predictions.jsonl` 保存逐条结果及规则证据；`models.json` 保存模型身份与路径；`summary.json` 保存完整逐配置、逐模型、逐规则和简洁系统分组统计及新漏检解释。SETTINGS.json 固定方案，EXECUTION.json 记录实际拟合次数和工程修正。原模型、历史数据和旧结果未作为汇总写入目标。
