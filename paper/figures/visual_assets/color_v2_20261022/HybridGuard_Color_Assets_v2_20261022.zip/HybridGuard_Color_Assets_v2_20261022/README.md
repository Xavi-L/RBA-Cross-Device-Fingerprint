# HybridGuard 全彩候选素材库 v2 — 2026-10-22

## 内容

37 项素材：App 9、Browser 5、平台与工具 4、时间 3、设备与几何 4、记录与规则 7、状态 5。
35 份原始 SVG + 2 份原始位图（WebView WebP、Puppeteer PNG）。
32 项本轮新增，5 项沿用先前已取得的彩色官方来源资产。

入口：HybridGuard_Color_Assets_Catalog_v2_20261022.html
两张预览板：boards/；单项 PNG：png/；原始矢量：svg/；原始位图：raster_original/。
精确来源、哈希、许可与用途：manifest.json、SOURCES.csv；许可文本：licenses/。

## 配色与使用

- 保留 App/浏览器 logo 原配色；品牌自身单色时不强行加色。
- 通用图标使用彩色填充，而非黑白轮廓染色。
- 黄三角警告、红菱形告警、绿圆勾通过、红斜杠停止、蓝问号未知。
- 原始 SVG 均保留。PNG 用 Inkscape 渲染，位图转换保持原分辨率。
- 预览板只对展示边缘空白进行裁剪和等比缩放，不改变原素材。
- 品牌可作生态示例，不代表研究已经评估所有这些 App/浏览器。
- 此次没有重画图2，没有修改论文、摘要或暂时冻结的图1。

## 来源身份

Chrome、Android、WebView、Playwright、Puppeteer 沿用此前保存的官方来源文件。
其他品牌包含 SuperTinyIcons 和 theSVG 的社区版本；不声称全部为官方商店原始图标。
通用图标主要来自 Icons8 Flat Color，黄色警告来自 Microsoft Fluent Color。
逐项权利情况及署名见 licenses/READ_ME_RIGHTS_AND_CREDITS.txt。

## 可复核性

32项本轮新增 SVG 的 Git blob SHA 与实际读取的源文件一致。
5项沿用原件的 SHA-256 与此前素材档案一致。
不包含字体文件，也不包含旧的黑白 Tabler 技术图标。
