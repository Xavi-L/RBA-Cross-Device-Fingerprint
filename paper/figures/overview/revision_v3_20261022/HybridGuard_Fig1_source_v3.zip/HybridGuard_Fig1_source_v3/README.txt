HYBRIDGUARD FIGURE 1 — REVIEW REDESIGN v3
Date: 2026-10-22
Status: Review draft. This package does not replace the main-paper figures or PDF.

CONTENTS
output/HybridGuard_Fig1_surfaces_v3.svg   Editable, self-contained vector source
output/HybridGuard_Fig1_surfaces_v3.pdf   One-page vector PDF, 178 x 79.111 mm
output/HybridGuard_Fig1_surfaces_v3.png   3000 px-wide preview
output/Fig1_print_width_150dpi.png       Reduced print-width readability preview
source/build_fig1.py                    Reproducible authoring and export script
assets/                                Exact component and technical icon assets
caption_proposal.txt                    Proposed caption, not applied to manuscript
figure_01_review.tex                    Suggested full-text-width figure insertion
qa_summary.json                        Validation and semantic boundaries

REBUILD
Install Python 3 and Inkscape. The script uses the Python standard library.
Fonts used: Nimbus Sans and Nimbus Roman (URW Base35); PDF exports embed used fonts.
Run from the package root:
    python3 source/build_fig1.py
The output files are regenerated under output/.
The SVG is self-contained and includes symbol definitions and its small WebView raster.
To edit text directly, use Inkscape with the listed fonts installed.

DESIGN
A mostly white, nested App/Host/Web structure occupies the left. Comparison arrows
and small technical symbols carry meaning. The right expands an associated App Web
and Browser timezone record into C1's applicability and condition-level outcome.
The offsets -480/-540 are illustrative, not reported experimental observations.

SEMANTIC BOUNDARIES
84/26/67/67 are schema field counts, not detector input counts.
Native--Web memory and timezone relations are integrated.
Host--Web geometry is a standalone study outside Integrated App and its candidate pool.
C1 uses valid association and observed finite numeric non-Boolean offsets.
C1 outcomes T/F/U/FAILED are condition-level outcomes; T is not the detector's ALERT.
C1 has no timestamp gate. Record leaders do not imply communication or synchrony.
No surface is trusted ground truth. Chrome 133/134 identifies evaluated implementations.

SOURCES
Paper semantics were checked against the current HybridGuard background/scope and
method sections and local implementation evidence. No manuscript text was changed.
Third-party source URLs, attribution and licenses: assets/asset_manifest.json,
assets/CREDITS.txt, assets/LICENSE-tabler.txt.
No third-party paper figure is redistributed in this package.
