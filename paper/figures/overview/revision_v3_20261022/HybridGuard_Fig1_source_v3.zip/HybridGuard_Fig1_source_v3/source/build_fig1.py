#!/usr/bin/env python3
"""Editable, exact SVG for HybridGuard Figure 1. No generated bitmap artwork."""
from pathlib import Path
from copy import deepcopy
import base64
import json
import math
import subprocess
import xml.etree.ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
ASSETS = PROJECT / 'assets'
OUT = PROJECT / 'output'
OUT.mkdir(parents=True, exist_ok=True)
NS = 'http://www.w3.org/2000/svg'
XL = 'http://www.w3.org/1999/xlink'
ET.register_namespace('', NS)
ET.register_namespace('xlink', XL)
W, H = 1800, 800
INK = '#242628'
FRAME = '#565b60'
GRAY = '#667078'
FAINT = '#d7dde1'
BLUE = '#326b96'
TEAL = '#287368'
OCHRE = '#a6772e'

def el(tag, parent=None, **attrs):
    attrs = {k.replace('_','-'): str(v) for k,v in attrs.items() if v is not None}
    n = ET.Element('{'+NS+'}'+tag, attrs)
    if parent is not None:
        parent.append(n)
    return n

svg = el('svg', width='178mm', height=f'{178*H/W:.5f}mm', viewBox=f'0 0 {W} {H}',
         role='img', aria_labelledby='title description')
el('title', svg, id='title').text = 'HybridGuard: associated observation surfaces and optional C1 relation'
el('desc', svg, id='description').text = (
    'A cooperating Android app contains Native APIs and a WebView Host; App Web JavaScript is nested in the Host. '
    'Native-Web memory and timezone comparisons are integrated. Host-Web geometry is a standalone study outside Integrated App and its candidate pool. '
    'The dotted Native-Host link denotes shared context only. Schema counts are Native 84, Host 26, App Web 67 and external Browser 67; selected detectors use subsets. '
    'The external Browser is a separate Web execution; Chrome 133 and 134 identify the evaluated implementation. '
    'A thin leader enlarges the App Web record into the C1 panel, not an additional execution. '
    'Illustrative App Web and Browser timezone offsets are -480 and -540 minutes under UTC-minus-local. '
    'Both show field status observed and quality observed_value. C1 requires valid association and finite numeric non-Boolean offsets. '
    'The illustrated inequality yields T, the C1 condition outcome, not the whole detector result. Equal usable offsets yield F; unusable evidence yields U; invalid association yields FAILED. '
    'C1 has no timestamp gate. Connectors denote comparison, containment, or record excerpts, not inter-application communication, synchronized sampling, or attestation. '
    'No surface is trusted ground truth. Android, Chrome and WebView icons are official identity assets; technical symbols use Tabler Icons.'
)
el('style', svg).text = '''
text {font-family:"Nimbus Sans",Arial,Helvetica,sans-serif}
.heading {font-family:"Nimbus Roman","Times New Roman",serif;font-weight:bold}
.field {font-family:"Nimbus Sans",Arial,Helvetica,sans-serif}
'''
defs = el('defs', svg)
for name, color in [('ochre',OCHRE),('teal',TEAL)]:
    m = el('marker',defs,id='head-'+name,markerWidth=12,markerHeight=12,refX=10,refY=6,
           orient='auto-start-reverse',markerUnits='userSpaceOnUse')
    el('path',m,d='M2 2 L10 6 L2 10',fill='none',stroke=color,stroke_width=2.2,
       stroke_linecap='round',stroke_linejoin='round')

def text(parent, x, y, content, size=28, color=INK, bold=False, anchor=None, family=None, **attrs):
    n = el('text',parent,x=x,y=y,font_size=size,fill=color,
           font_weight='bold' if bold else None,text_anchor=anchor,
           font_family=family,**attrs)
    n.text = content
    return n

def rect(parent,x,y,w,h,fill='white',stroke=FRAME,sw=2,rx=3,**attrs):
    return el('rect',parent,x=x,y=y,width=w,height=h,fill=fill,stroke=stroke,stroke_width=sw,rx=rx,**attrs)

def path(parent,d,stroke=FRAME,sw=2,fill='none',**attrs):
    return el('path',parent,d=d,stroke=stroke,stroke_width=sw,fill=fill,
              stroke_linejoin='round',stroke_linecap='round',**attrs)

def symbol_from_svg(filename,symbol_id):
    src=ET.parse(ASSETS/filename).getroot()
    vb=src.get('viewBox') or f"0 0 {src.get('width','24')} {src.get('height','24')}"
    s=el('symbol',defs,id=symbol_id,viewBox=vb)
    for k,v in src.attrib.items():
        if k not in ['width','height','viewBox','id']:
            s.set(k,v)
    for n in src:
        s.append(deepcopy(n))
    # Keep third-party geometry; prefix IDs to keep the SVG self-contained.
    ids={n.get('id'):symbol_id+'-'+n.get('id') for n in s.iter() if n is not s and n.get('id')}
    for n in s.iter():
        for k,v in list(n.attrib.items()):
            for old,new in ids.items():
                v=v.replace('url(#'+old+')','url(#'+new+')')
            n.set(k,ids.get(v,v) if k=='id' else v)
    return symbol_id

symbols={}
for short in ['memory','clock','dimensions','browser','files','link']:
    symbols[short]=symbol_from_svg('tabler-'+short+'.svg','icon-'+short)
symbols['android']=symbol_from_svg('android-head_flat.svg','brand-android')
symbols['chrome']=symbol_from_svg('chrome-logo-m100.svg','brand-chrome')

def icon(parent,name,x,y,w=32,h=None,color=INK):
    n=el('use',parent,x=x,y=y,width=w,height=h or w,color=color)
    n.set('{'+XL+'}href','#'+symbols[name])
    return n

def raster(parent,filename,x,y,w,h):
    p=ASSETS/filename
    n=el('image',parent,x=x,y=y,width=w,height=h,preserveAspectRatio='xMidYMid meet')
    n.set('{'+XL+'}href','data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode())

def count(parent,x,y,n):
    rect(parent,x,y,107,34,fill='#f5f6f7',stroke=FAINT,sw=1.3,rx=3)
    text(parent,x+53.5,y+25,str(n)+' fields',24,GRAY,anchor='middle')

def comparison_arrow(parent,x1,y1,x2,y2,color=BLUE,shaft=14,head=29):
    dx,dy=x2-x1,y2-y1
    L=math.hypot(dx,dy)
    ux,uy=dx/L,dy/L
    px,py=-uy,ux
    def pt(a,b): return (x1+a*ux+b*px,y1+a*uy+b*py)
    pts=[pt(0,0),pt(head,-head/1.25),pt(head,-shaft/2),pt(L-head,-shaft/2),
         pt(L-head,-head/1.25),pt(L,0),pt(L-head,head/1.25),pt(L-head,shaft/2),
         pt(head,shaft/2),pt(head,head/1.25)]
    return el('polygon',parent,points=' '.join(f'{x:.2f},{y:.2f}' for x,y in pts),
              fill=color,stroke=color,stroke_width=1)

rect(svg,0,0,W,H,stroke='none',sw=0,rx=0)

# APP EXECUTION: real containment plus three semantic comparison relationships.
app=el('g',svg,id='same-app-execution',data_kind='execution-container')
rect(app,18,36,1037,692,stroke=FRAME,sw=2.2,rx=5)
rect(app,38,15,430,45,stroke='none',sw=0,rx=0)
text(app,49,51,'Cooperating Android app',39,bold=True,**{'class':'heading'})
text(app,49,94,'Same execution · associated observations',28,GRAY)

# Native record, slightly offset source-page edges (one record excerpt).
native=el('g',app,id='native-observation',data_schema_fields=84)
path(native,'M64 199 H386 V508',stroke='#a6acb1',sw=1.5)
rect(native,48,211,340,318,stroke=FRAME,sw=2,rx=3)
icon(native,'android',68,230,58,34)
text(native,141,260,'Native APIs',34,bold=True,**{'class':'heading'})
text(native,72,299,'Device & OS',28,GRAY)
path(native,'M70 315 H366',stroke=FAINT,sw=1.3)
icon(native,'memory',73,334,30)
text(native,118,359,'totalMem (GiB)',28)
icon(native,'clock',73,386,30)
text(native,118,410,'IANA timezone',28)
text(native,118,449,'collection interval',25,GRAY)
count(native,72,478,84)

# Host provides a visible container enclosing App Web.
host=el('g',app,id='webview-host',data_schema_fields=26)
rect(host,594,124,431,480,stroke=FRAME,sw=2.1,rx=4)
rect(host,610,105,278,39,stroke='none',sw=0,rx=0)
raster(host,'android-system-webview.png',610,112,36,36)
text(host,658,142,'WebView Host',34,bold=True,**{'class':'heading'})
count(host,903,107,26)

web=el('g',host,id='app-web-observation',data_schema_fields=67)
path(web,'M638 168 H1005 V409',stroke='#a6acb1',sw=1.5)
rect(web,623,181,370,238,stroke=FRAME,sw=1.9,rx=3)
rect(web,624,182,368,47,fill='#f3f6f7',stroke='none',sw=0,rx=0)
rect(web,645,192,43,30,fill='white',stroke=GRAY,sw=1.2,rx=1)
text(web,666.5,216,'JS',24,bold=True,anchor='middle')
text(web,707,217,'App Web',33,bold=True,**{'class':'heading'})
count(web,878,190,67)
text(web,648,263,'Embedded webpage',28,GRAY)
icon(web,'memory',648,284,28)
text(web,693,309,'deviceMemory',28)
icon(web,'clock',648,326,28)
text(web,693,351,'timezone_offset',28)
icon(web,'dimensions',648,368,28)
text(web,693,393,'visualViewport',28)

geometry=el('g',host,id='standalone-host-web-geometry',data_status='standalone')
path(geometry,'M651 428 V492',stroke=OCHRE,sw=3.2,stroke_dasharray='8 7',
     marker_start='url(#head-ochre)',marker_end='url(#head-ochre)')
text(geometry,686,455,'Geometry',30,OCHRE,bold=True)
text(geometry,686,487,'Standalone study',26,OCHRE)
rect(host,623,506,370,76,stroke='#999fa4',sw=1.5,rx=2)
icon(host,'dimensions',642,522,30,color=GRAY)
text(host,687,540,'View bounds · padding',26)
text(host,647,570,'View transform · stability',25,GRAY)

integrated=el('g',app,id='integrated-native-web',data_relation='memory-and-timezone')
text(integrated,410,179,'Native-Web',31,BLUE,bold=True,**{'class':'heading'})
text(integrated,410,214,'consistency',31,BLUE,bold=True,**{'class':'heading'})
icon(integrated,'memory',410,242,28,color=BLUE)
text(integrated,451,266,'Memory',28,BLUE)
icon(integrated,'clock',410,279,28,color=BLUE)
text(integrated,451,303,'Timezone',28,BLUE)
comparison_arrow(integrated,392,370,625,335)
text(integrated,498,415,'Integrated',26,BLUE,anchor='middle')
text(integrated,498,444,'relations',26,BLUE,anchor='middle')

context=el('g',app,id='native-host-context',data_status='context-only')
path(context,'M392 479 L613 546',stroke='#8d969e',sw=2.6,stroke_dasharray='1 8')
rect(context,399,535,182,64,fill='white',stroke='none',sw=0,rx=0)
text(context,490,556,'Shared context',25,GRAY,anchor='middle')
text(context,490,585,'only',25,GRAY,anchor='middle')

# Record content retained for binding; this is not a runtime decision pipeline.
record=el('g',app,id='record-context')
rect(record,48,636,977,68,stroke='#9fa7ad',sw=1.4,rx=3)
rect(record,66,617,344,32,stroke='none',sw=0,rx=0)
text(record,76,641,'Preserved observation context',27,GRAY)
icon(record,'files',70,660,29,color=GRAY)
text(record,112,684,'Values',27)
path(record,'M244 653 V693',stroke=FAINT,sw=1.3)
text(record,274,684,'Collection states',27)
path(record,'M511 653 V693',stroke=FAINT,sw=1.3)
text(record,541,684,'Sources',27)
path(record,'M689 653 V693',stroke=FAINT,sw=1.3)
icon(record,'link',717,660,29,color=GRAY)
text(record,760,684,'Association context',27)

# EXTERNAL BROWSER stays outside the App boundary. Chrome is an evaluated implementation badge.
browser=el('g',svg,id='external-browser',data_kind='separate-web-execution',data_schema_fields=67)
rect(browser,1107,42,674,215,stroke=FRAME,sw=2.1,rx=5)
path(browser,'M1108 110 H1780',stroke=FAINT,sw=1.5)
icon(browser,'browser',1131,62,38)
text(browser,1185,93,'External Browser',37,bold=True,**{'class':'heading'})
count(browser,1656,64,67)
text(browser,1131,148,'Separate Web execution',28,GRAY)
for name,x,label in [('memory',1132,'memory'),('clock',1342,'timezone'),('dimensions',1553,'viewport')]:
    icon(browser,name,x,171,29)
    text(browser,x+43,195,label,27)
icon(browser,'chrome',1134,212,29)
text(browser,1179,236,'Evaluated: Chrome 133 / 134',25,GRAY)

# Thin leaders denote record excerpts, not transport between executions.
leaders=el('g',svg,id='record-excerpt-leaders')
path(leaders,'M993 344 H1080 V461 H1118',stroke=TEAL,sw=2.5)
el('circle',leaders,cx=993,cy=344,r=4,fill=TEAL)
path(leaders,'M1746 257 V310',stroke=TEAL,sw=2.5)
el('circle',leaders,cx=1746,cy=257,r=4,fill=TEAL)

c1=el('g',svg,id='optional-c1',data_kind='condition-level-comparison')
rect(c1,1107,310,674,418,stroke=TEAL,sw=2.1,rx=5)
rect(c1,1123,290,385,40,stroke='none',sw=0,rx=0)
text(c1,1134,321,'C1 · Timezone relation',35,TEAL,bold=True,**{'class':'heading'})
rect(c1,1533,292,128,34,stroke='none',sw=0,rx=0)
text(c1,1597,317,'Optional',27,TEAL,anchor='middle')
text(c1,1127,355,'Illustrative linked records · min (UTC - local)',25,GRAY)
path(c1,'M1108 461 H1127',stroke=TEAL,sw=2.5)
path(c1,'M1746 310 V365 H1606 V381',stroke=TEAL,sw=2.5)

def excerpt(parent,x,y,w,name,offset,id_):
    g=el('g',parent,id=id_,data_kind='record-excerpt',data_example='illustrative')
    path(g,f'M{x+11} {y-10} H{x+w+10} V{y+187}',stroke='#a7b7b3',sw=1.4)
    rect(g,x,y,w,193,stroke=FRAME,sw=1.7,rx=2)
    rect(g,x+1,y+1,w-2,40,fill='#f1f6f4',stroke='none',sw=0,rx=0)
    text(g,x+17,y+30,name,30,bold=True,**{'class':'heading'})
    text(g,x+17,y+71,'timezone_offset',25)
    text(g,x+17,y+111,offset+' min',35,TEAL,bold=True)
    text(g,x+17,y+148,'status: observed',25,GRAY)
    text(g,x+17,y+178,'quality: observed_value',24,GRAY)
    return g

excerpt(c1,1127,381,304,'App Web record','−480','c1-app-excerpt')
excerpt(c1,1453,381,304,'Browser record','−540','c1-browser-excerpt')

# Both operands feed the same association/applicability gate.
path(c1,'M1280 574 V586 H1606 V574',stroke=TEAL,sw=2.5)
path(c1,'M1443 586 V601',stroke=TEAL,sw=2.5)
rect(c1,1127,601,630,39,fill='white',stroke=TEAL,sw=1.6,rx=2)
text(c1,1442,628,'Valid association · observed, finite operands',26,TEAL,anchor='middle')
el('polygon',c1,points='1433,640 1453,640 1453,649 1463,649 1443,667 1423,649 1433,649',fill=TEAL)
text(c1,1144,690,'o',33,TEAL,family='Nimbus Roman')
text(c1,1160,699,'A',23,TEAL,family='Nimbus Roman')
text(c1,1183,690,'≠',33,TEAL)
text(c1,1222,690,'o',33,TEAL,family='Nimbus Roman')
text(c1,1238,699,'B',23,TEAL,family='Nimbus Roman')
text(c1,1301,690,'→',34,TEAL)
text(c1,1351,690,'T · Offset mismatch',30,TEAL,bold=True)
text(c1,1443,719,'Equal → F · Unusable → U · Invalid link → FAILED',24,GRAY,anchor='middle')

path(svg,'M20 750 H1780',stroke=FAINT,sw=1.3)
text(svg,25,783,'Counts describe schemas, not selected inputs. No surface is trusted ground truth.',26,GRAY)
text(svg,1774,783,'C1: no timestamp gate',25,GRAY,anchor='end')

svg_path=OUT/'HybridGuard_Fig1_surfaces_v3.svg'
ET.ElementTree(svg).write(svg_path,encoding='utf-8',xml_declaration=True)
pdf_path=OUT/'HybridGuard_Fig1_surfaces_v3.pdf'
png_path=OUT/'HybridGuard_Fig1_surfaces_v3.png'
subprocess.run(['inkscape',str(svg_path),'--export-type=pdf','--export-area-page',
                '--export-filename='+str(pdf_path)],check=True,capture_output=True)
subprocess.run(['inkscape',str(svg_path),'--export-type=png','--export-area-page','--export-width=3000',
                '--export-filename='+str(png_path)],check=True,capture_output=True)
subprocess.run(['inkscape',str(svg_path),'--export-type=png','--export-area-page','--export-width=1051',
                '--export-filename='+str(OUT/'Fig1_print_width_150dpi.png')],check=True,capture_output=True)
print(json.dumps({'svg':str(svg_path),'pdf':str(pdf_path),'png':str(png_path),'paper_width_mm':178,
                  'paper_height_mm':178*H/W,'smallest_text_px':23,'main_body_px':'25–28',
                  'status':'review draft'},ensure_ascii=False,indent=2))
