#!/usr/bin/env python3
"""Exact editable SVG for the HybridGuard construction and evaluation pipeline."""
from pathlib import Path
from copy import deepcopy
import base64
import json
import subprocess
import xml.etree.ElementTree as ET

PROJECT = Path(__file__).resolve().parents[1]
ASSETS = PROJECT / 'assets'
OUT = PROJECT / 'output'
OUT.mkdir(parents=True, exist_ok=True)
NS = 'http://www.w3.org/2000/svg'
XL = 'http://www.w3.org/1999/xlink'
ET.register_namespace('', NS)
ET.register_namespace('xlink', XL)
W, H = 1800, 1100
INK = '#242628'
FRAME = '#565b60'
GRAY = '#667078'
FAINT = '#d7dde1'
BLUE = '#326b96'
TEAL = '#287368'
OCHRE = '#a6772e'
RUST = '#a4543f'

def el(tag, parent=None, **attrs):
    n = ET.Element('{'+NS+'}'+tag, {k.replace('_','-'):str(v) for k,v in attrs.items() if v is not None})
    if parent is not None: parent.append(n)
    return n

svg=el('svg',width='178mm',height=f'{178*H/W:.5f}mm',viewBox=f'0 0 {W} {H}',role='img',aria_labelledby='title description')
el('title',svg,id='title').text='HybridGuard: offline rule construction and current-record evaluation'
el('desc',svg,id='description').text=(
    'Offline construction uses controlled training material and MTC discovery normals. Playwright and Puppeteer are examples of controlled modification recipe tools, not runtime components. '
    'The App pool contains 50 App-Web base templates plus three fixed relations: Native memory, Native timezone and same-Web viewport. '
    'Only controlled training fits encoding and threshold expansion. MTC discovery normals enter admission and the normal constraints, not threshold fitting. Fixed relations themselves do not fit thresholds. '
    'Sparse selection maximizes J(S) = (1/14) sum_k d_k(S) - 0.005 C(S), where C counts clauses plus literal occurrences. '
    'The heuristic uses greedy improving additions, the best feasible prefix and backward pruning; it permits at most eight singleton clauses, two conditions per family, and no opposite polarities of an atom. '
    'Retention begins from each sparse solution, preserves detections and constraints, and adds semantic coverage or swaps within a semantic group for predefined higher quality. Retention does not continue to maximize J. '
    'Saved retained App rules, selected polarities and parameters are frozen. Integrated App and Integrated App plus C1 are separately evaluated configurations. C1 extends the frozen App model and is not part of the 50-plus-3 App candidate pool. '
    'The thick blue connector supplies these frozen checks to evaluation without refitting. Current App records contain Native, Host and App Web observations; the linked Browser is used only in the C1 configuration. '
    'Binding preserves values, collection status and quality, sources, and association context. Only selected required inputs affect the failure policy. '
    'Each selected singleton clause produces T, F, U or FAILED. The Native memory example is a real retained positive condition: Web memory exceeds 2 raised to ceil(log2(Native memory)). Other selected App predicates are configuration dependent. '
    'The ordered decision returns the first matching case: EMPTY_MODEL for an empty selection; FAILED for a relevant required execution or binding failure; otherwise ALERT for any T; NO ALERT for all F; UNKNOWN for remaining cases. '
    'T means trigger, F definite non-trigger and U unknown. The logical example App F plus C1 U yields UNKNOWN; it is not a new experimental record and has no relevant failure. '
    'Output includes the detector state, per-check results and associated evidence. Current-record evaluation does not read intervention labels or recovery records. '
    'Host geometry remains standalone outside the candidate pool and selected checks. NO ALERT does not certify authenticity.'
)
el('style',svg).text='''text {font-family:"Nimbus Sans",Arial,Helvetica,sans-serif}
.heading {font-family:"Nimbus Roman","Times New Roman",serif;font-weight:bold}
'''
defs=el('defs',svg)
for name,color in [('gray',GRAY),('blue',BLUE),('teal',TEAL)]:
    m=el('marker',defs,id='arrow-'+name,markerWidth=13,markerHeight=13,refX=11,refY=6.5,orient='auto',markerUnits='userSpaceOnUse')
    el('path',m,d='M2 2 L11 6.5 L2 11 Z',fill=color)

def text(parent,x,y,content,size=28,color=INK,bold=False,anchor=None,**attrs):
    n=el('text',parent,x=x,y=y,font_size=size,fill=color,font_weight='bold' if bold else None,text_anchor=anchor,**attrs)
    n.text=content
    return n

def heading(parent,x,y,content,size=33,color=INK):
    return text(parent,x,y,content,size,color,True,**{'class':'heading'})

def rect(parent,x,y,w,h,fill='white',stroke=FRAME,sw=1.8,rx=3,**attrs):
    return el('rect',parent,x=x,y=y,width=w,height=h,fill=fill,stroke=stroke,stroke_width=sw,rx=rx,**attrs)

def path(parent,d,color=FRAME,sw=2,fill='none',arrow=None,**attrs):
    return el('path',parent,d=d,fill=fill,stroke=color,stroke_width=sw,stroke_linejoin='round',stroke_linecap='round',marker_end='url(#arrow-'+arrow+')' if arrow else None,**attrs)

def symbol_from_svg(filename,symbol_id):
    src=ET.parse(ASSETS/filename).getroot()
    vb=src.get('viewBox') or f"0 0 {src.get('width','24')} {src.get('height','24')}"
    s=el('symbol',defs,id=symbol_id,viewBox=vb)
    for k,v in src.attrib.items():
        if k not in ['width','height','viewBox','id']:s.set(k,v)
    for n in src:s.append(deepcopy(n))
    ids={n.get('id'):symbol_id+'-'+n.get('id') for n in s.iter() if n is not s and n.get('id')}
    for n in s.iter():
        for k,v in list(n.attrib.items()):
            for old,new in ids.items():v=v.replace('url(#'+old+')','url(#'+new+')')
            n.set(k,ids.get(v,v) if k=='id' else v)
    return symbol_id

symbols={n:symbol_from_svg('tabler-'+n+'.svg','icon-'+n) for n in ['database','files','filter','link','memory','clock','dimensions','browser']}
symbols['android']=symbol_from_svg('android-head_flat.svg','brand-android')
symbols['playwright']=symbol_from_svg('playwright.svg','brand-playwright')

def icon(parent,name,x,y,w=30,h=None,color=INK):
    n=el('use',parent,x=x,y=y,width=w,height=h or w,color=color)
    n.set('{'+XL+'}href','#'+symbols[name])
    return n

def raster(parent,filename,x,y,w,h):
    n=el('image',parent,x=x,y=y,width=w,height=h,preserveAspectRatio='xMidYMid meet')
    n.set('{'+XL+'}href','data:image/png;base64,'+base64.b64encode((ASSETS/filename).read_bytes()).decode())
    return n

def stack(parent,x,y,w,h,color=FRAME):
    path(parent,f'M{x+12} {y-11} H{x+w+11} V{y+h-11}',color='#a9b0b5',sw=1.4)
    rect(parent,x,y,w,h,stroke=color)

def check(parent,x,y,color=BLUE):
    path(parent,f'M{x} {y+7} L{x+7} {y+14} L{x+21} {y-4}',color,2.5)

def step(parent,x,y,n,label,size=31):
    el('circle',parent,cx=x+13,cy=y-11,r=14,fill=INK)
    text(parent,x+13,y-3,str(n),23,'white',True,'middle')
    heading(parent,x+37,y,label,size)

rect(svg,0,0,W,H,stroke='none',sw=0,rx=0)
heading(svg,24,41,'Offline rule construction',39)
text(svg,454,39,'Training material only',27,GRAY)

# Controlled records and discovery normals are data objects, not generic flat stages.
training=el('g',svg,id='training-material',data_scope='training-only')
heading(training,40,104,'Training records',32)
stack(training,40,131,298,188)
heading(training,58,164,'Controlled training',29)
text(training,58,198,'14 recipes · 2 envs',25)
text(training,58,230,'Recipe tools (examples)',24,GRAY)
icon(training,'playwright',90,242,46)
raster(training,'puppeteer-official.png',246,241,32,47)
text(training,112,309,'Playwright',24,GRAY,anchor='middle')
text(training,261,309,'Puppeteer',24,GRAY,anchor='middle')
stack(training,40,351,298,70)
icon(training,'database',57,366,29,color=GRAY)
heading(training,102,380,'MTC discovery',28)
text(training,102,409,'630 training normals',25,GRAY)

# Train-only expansion and admission share a candidate container but remain distinct.
candidate=el('g',svg,id='candidate-pool',data_base_templates=50,data_fixed_relations=3)
rect(candidate,388,89,366,332)
heading(candidate,405,126,'Candidate pool',32)
text(candidate,405,163,'50 base templates + 3 fixed',25,BLUE,True)
for y,ic,label in [(191,'memory','Native memory'),(227,'clock','Native timezone'),(263,'dimensions','Same-Web viewport')]:
    icon(candidate,ic,408,y-23,27,color=GRAY)
    text(candidate,449,y,label,27)
path(candidate,'M405 281 H737',FAINT,1.3)
text(candidate,405,310,'Controlled-only expansion',26,BLUE,True)
text(candidate,405,341,'Encoding + thresholds',25,GRAY)
rect(candidate,405,358,332,49,fill='#f7f9fa',stroke='#a4adb4',sw=1.3)
icon(candidate,'filter',415,368,25,color=BLUE)
text(candidate,453,379,'Admission',25,BLUE,True)
text(candidate,453,402,'Polarity · assessability',24,GRAY)

# Sparse objective and search, kept visibly separate from retention.
sparse=el('g',svg,id='sparse-selection')
rect(sparse,797,89,282,332)
heading(sparse,815,126,'Sparse selection',32)
text(sparse,815,169,'Maximize J(S)',29,BLUE,True)
text(sparse,815,204,'Detection − 0.005 C',25)
text(sparse,815,235,'C: clauses + literals',24,GRAY)
for x,w,label in [(815,59,'add'),(895,76,'prefix'),(992,69,'prune')]:
    rect(sparse,x,258,w,36,stroke='#9aa5af',sw=1.2,rx=2)
    text(sparse,x+w/2,284,label,24,GRAY,anchor='middle')
path(sparse,'M875 276 H891',GRAY,1.6,arrow='gray')
path(sparse,'M972 276 H988',GRAY,1.6,arrow='gray')
text(sparse,815,329,'≤ 8 singleton clauses',25)
text(sparse,815,364,'≤ 2 conditions / family',25)
text(sparse,815,399,'No opposite polarities',24,GRAY)

retention=el('g',svg,id='retention')
rect(retention,1120,89,285,332)
heading(retention,1139,126,'Retention',32)
rect(retention,1138,151,249,87,stroke='#9ca9b4',sw=1.3)
text(retention,1152,188,'+',35,BLUE,True)
text(retention,1191,184,'Semantic',27,BLUE,True)
text(retention,1191,219,'coverage',27,BLUE,True)
rect(retention,1138,258,249,87,stroke='#9ca9b4',sw=1.3)
text(retention,1150,298,'↔',32,BLUE,True)
text(retention,1191,293,'Quality swaps',27,BLUE,True)
text(retention,1152,327,'Same semantic group',24)
check(retention,1142,377)
text(retention,1176,384,'Keep detections',25)
text(retention,1176,412,'and constraints',25)

# Frozen retained App model. C1 sits on a separate extension strip.
frozen=el('g',svg,id='frozen-rules',data_status='saved-retention-model')
heading(frozen,1464,104,'Frozen model',32)
path(frozen,'M1489 122 H1780 V314',color='#b4bbc0',sw=1.3)
stack(frozen,1463,144,301,193,color=BLUE)
heading(frozen,1481,182,'Frozen App rules',31,BLUE)
path(frozen,'M1480 198 H1748',FAINT,1.3)
icon(frozen,'files',1481,216,28,color=GRAY)
text(frozen,1524,240,'Selected checks',27)
text(frozen,1481,275,'Polarities + parameters',25)
text(frozen,1481,309,'Integrated App',26,BLUE)
rect(frozen,1463,360,301,61,stroke=TEAL,sw=1.7,stroke_dasharray='7 5')
text(frozen,1481,387,'+ C1 extension',28,TEAL,True)
text(frozen,1481,414,'App + Browser',24,GRAY)
text(frozen,1613,449,'Two evaluated configurations',24,GRAY,anchor='middle')

for x1,x2 in [(340,386),(1081,1118),(1407,1461)]:
    path(svg,f'M{x1} 244 H{x2}',GRAY,2.5,arrow='gray')
path(svg,'M340 386 H403',GRAY,2.3,arrow='gray')
path(svg,'M755 383 H775 V244 H795',GRAY,2.5,arrow='gray')
text(svg,406,450,'Shared constraints: alarm budgets · assessability · definite-output coverage',26,GRAY)
path(svg,'M22 475 H1780',FAINT,1.4)

# The only broad supply connector: frozen artifact to selected-check evaluation.
supply=el('g',svg,id='frozen-model-supply',data_kind='configuration-supply')
path(supply,'M1764 314 H1774 V491 H1127 V644 H1118',BLUE,13)
path(supply,'M1764 390 H1774',TEAL,2.4)
el('polygon',supply,points='1104,644 1126,626 1126,662',fill=BLUE)
text(supply,1450,527,'Frozen checks + parameters',27,BLUE,anchor='middle')

heading(svg,24,527,'Current-record evaluation',39)
step(svg,24,576,1,'Bind observations',32)
step(svg,596,576,2,'Evaluate selected checks',32)
step(svg,1152,576,3,'Resolve and return',32)

# Current App and optional Browser records join at an explicit binding panel.
current=el('g',svg,id='current-records',data_scope='current-only')
stack(current,40,627,217,165)
icon(current,'android',57,645,39,23)
heading(current,107,668,'App record',28)
path(current,'M56 683 H242',FAINT,1.3)
text(current,59,714,'Native',28)
text(current,59,747,'WebView Host',28)
text(current,59,780,'App Web',28)
rect(current,40,840,217,80,stroke=TEAL,stroke_dasharray='7 5')
icon(current,'browser',57,852,25,color=TEAL)
heading(current,96,875,'Browser',28,TEAL)
text(current,57,907,'Linked · C1 only',25,GRAY)

binding=el('g',svg,id='bind-records')
rect(binding,313,700,242,187,stroke=FRAME)
icon(binding,'link',328,713,29,color=BLUE)
heading(binding,370,739,'Bind records',28)
path(binding,'M329 752 H540',FAINT,1.3)
text(binding,330,782,'Values · Status',27)
text(binding,330,817,'Quality · Sources',27)
text(binding,330,852,'Association context',25)
text(binding,434,877,'Required inputs',24,GRAY,anchor='middle')
path(svg,'M258 711 H282 V792 H311',GRAY,2.5,arrow='gray')
path(svg,'M258 880 H282 V792',TEAL,2.3)
el('circle',svg,cx=282,cy=792,r=4,fill=GRAY)
path(svg,'M557 792 H594',GRAY,2.5,arrow='gray')

# Selected clauses are visible rule objects. Exact memory relation is in desc.
evaluation=el('g',svg,id='selected-check-evaluation')
rect(evaluation,596,617,508,331,stroke='#8e9aa3',sw=1.8)
rect(evaluation,613,600,310,35,stroke='none',sw=0,rx=0)
text(evaluation,624,626,'Selected singleton clauses',26,GRAY)
stack(evaluation,617,657,464,74)
icon(evaluation,'memory',631,672,29,color=BLUE)
heading(evaluation,675,693,'Native memory',29)
text(evaluation,632,721,'Web memory > Native-derived bound',25,GRAY)
rect(evaluation,617,746,464,58,stroke='#8e9aa3',sw=1.5)
icon(evaluation,'files',633,761,27,color=GRAY)
text(evaluation,675,782,'Other selected App predicates',27)
rect(evaluation,617,821,464,67,stroke=TEAL,sw=1.7,stroke_dasharray='7 5')
icon(evaluation,'clock',632,835,27,color=TEAL)
heading(evaluation,675,850,'C1 · linked timezone',28,TEAL)
text(evaluation,632,878,'App + Browser configuration',25,GRAY)
text(evaluation,617,931,'r',29,GRAY)
text(evaluation,628,939,'j',21,GRAY)
text(evaluation,644,931,'∈',27,GRAY)
states=[(680,64,'T',RUST),(757,64,'F',GRAY),(834,64,'U',OCHRE),(911,170,'FAILED',INK)]
for x,w,label,color in states:
    rect(evaluation,x,904,w,35,fill='white',stroke=color,sw=1.4,rx=3)
    text(evaluation,x+w/2,931,label,25,color,True,'middle')
path(svg,'M1106 792 H1148',GRAY,2.7,arrow='gray')

# First matching case is the actual priority order, not voting or a score.
decision=el('g',svg,id='ordered-resolution',data_policy='first-matching-case')
text(decision,1153,608,'Ordered tests · first matching case',26,GRAY)
rect(decision,1152,628,628,320,stroke=FRAME)
rows=[
    ('Empty selected set','EMPTY_MODEL',GRAY,'empty'),
    ('Required execution / binding failure','FAILED',INK,'failure'),
    ('Otherwise, any T','ALERT',RUST,'alert'),
    ('Otherwise, all F','NO ALERT',GRAY,'none'),
    ('Otherwise','UNKNOWN',OCHRE,'unknown')
]
for i,(cond,out,color,symbol) in enumerate(rows):
    y=628+i*64
    if i:path(decision,f'M1152 {y} H1780',FAINT,1.2)
    text(decision,1173,y+40,str(i+1),25,GRAY)
    if i==1:
        text(decision,1204,y+27,'Required execution /',25)
        text(decision,1204,y+55,'binding failure',25)
    else:text(decision,1204,y+40,cond,26)
    path(decision,f'M1479 {y+32} H1507',GRAY,1.8,arrow='gray')
    if symbol=='empty':
        el('circle',decision,cx=1533,cy=y+32,r=9,fill='none',stroke=color,stroke_width=1.7)
        path(decision,f'M1524 {y+43} L1542 {y+21}',color,1.7)
    elif symbol=='failure':
        path(decision,f'M1524 {y+23} L1542 {y+41} M1542 {y+23} L1524 {y+41}',color,2.8)
    elif symbol=='alert':
        el('polygon',decision,points=f'1533,{y+19} 1546,{y+43} 1520,{y+43}',fill='none',stroke=color,stroke_width=1.8)
        text(decision,1533,y+40,'!',22,color,True,'middle')
    elif symbol=='none':path(decision,f'M1523 {y+32} H1543',color,2.6)
    else:text(decision,1533,y+41,'?',29,color,True,'middle')
    text(decision,1558,y+40,out,26,color,True)

# A logic example is separate from the evidence stream; it adds no experiment.
example=el('g',svg,id='decision-example',data_kind='logical-example')
rect(example,40,980,1064,62,stroke='#a2acb4',sw=1.3)
text(example,59,1005,'Decision example · linked mode',24,GRAY)
text(example,59,1033,'App: F + C1: U  →  UNKNOWN',28,OCHRE,True)
text(example,1084,1005,'T: trigger · F: definite non-trigger',24,GRAY,anchor='end')
text(example,1084,1033,'U: unknown · FAILED: required failure',24,GRAY,anchor='end')

result=el('g',svg,id='returned-result')
stack(result,1152,981,628,61)
icon(result,'files',1169,997,29,color=GRAY)
text(result,1214,1006,'Return state + check results + evidence',26,GRAY)
text(result,1214,1034,'No alert does not certify authenticity.',24,GRAY)
path(svg,'M22 1060 H1780',FAINT,1.3)
text(svg,25,1090,'Current records only; no intervention labels or recovery records.',25,GRAY)
text(svg,1776,1090,'Host geometry: standalone, outside selected checks.',25,GRAY,anchor='end')

svg_path=OUT/'HybridGuard_Fig2_pipeline_v3.svg'
ET.ElementTree(svg).write(svg_path,encoding='utf-8',xml_declaration=True)
pdf_path=OUT/'HybridGuard_Fig2_pipeline_v3.pdf'
png_path=OUT/'HybridGuard_Fig2_pipeline_v3.png'
subprocess.run(['inkscape',str(svg_path),'--export-type=pdf','--export-area-page','--export-filename='+str(pdf_path)],check=True,capture_output=True)
subprocess.run(['inkscape',str(svg_path),'--export-type=png','--export-area-page','--export-width=3000','--export-filename='+str(png_path)],check=True,capture_output=True)
subprocess.run(['inkscape',str(svg_path),'--export-type=png','--export-area-page','--export-width=1051','--export-filename='+str(OUT/'Fig2_print_width_150dpi.png')],check=True,capture_output=True)
print(json.dumps({'svg':str(svg_path),'pdf':str(pdf_path),'png':str(png_path),'paper_width_mm':178,'paper_height_mm':178*H/W,'status':'review draft'},indent=2))
