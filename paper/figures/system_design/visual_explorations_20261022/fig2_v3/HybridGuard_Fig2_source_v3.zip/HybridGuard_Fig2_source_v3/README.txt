HYBRIDGUARD FIGURE 2 — REVIEW REDESIGN v3
Date: 2026-10-22
Status: Figure 2 review draft. Figure 1 v3 is temporarily frozen by the user's instruction.
The Figure 1 artwork and the main manuscript/PDF have not been changed.

CONTENTS
output/HybridGuard_Fig2_pipeline_v3.svg   Editable, self-contained vector source
output/HybridGuard_Fig2_pipeline_v3.pdf   One-page PDF, 178 x 108.778 mm, embedded fonts
output/HybridGuard_Fig2_pipeline_v3.png   3000 px-wide preview
output/Fig2_print_width_150dpi.png       Print-width readability preview
source/build_fig2.py                    Reproducible SVG authoring and PDF/PNG export
assets/                                Exact original assets, sources and attribution
caption_proposal.txt                    Proposed caption, not applied to the manuscript
figure_02_review.tex                    Suggested full-text-width figure insertion
figure_status.json                     User freeze decision and Figure 1 file hashes
qa_summary.json                        Layout, semantic and export checks

REBUILD
Install Python 3 and Inkscape. The authoring script uses the Python standard library.
Fonts: Nimbus Sans and Nimbus Roman (URW Base35). Used fonts are embedded in the PDF.
Run from the package root:
    python3 source/build_fig2.py
The exports are written to output/.
The SVG is self-contained: brand/technical SVG symbols and the Puppeteer raster are embedded.
The diagram remains object-editable in Inkscape; install the listed fonts for the closest text match.

DESIGN
Upper band: training record objects, explicit candidate expansion/admission, sparse search,
semantic retention, and saved rule objects. The single thick blue connector supplies the
frozen configuration to the lower evaluation band. Current data uses thin connectors.
The right decision list is ordered; symbols indicate an empty set, failure, alert, no alert,
and unknown, rather than decorative pass/fail marks.

SEMANTIC BOUNDARIES
Only controlled training fits encodings and thresholds. MTC discovery normals connect
independently to admission/normal constraints.
The App pool is 50 App-Web base templates plus three fixed relations: Native memory,
Native timezone, and same-Web viewport. Host geometry is outside this pool.
Sparse selection optimizes J; retention preserves detections and constraints and adds semantic
coverage or registered within-group quality swaps. Retention does not continue to optimize J.
C1 extends the frozen App base; it is outside the 50+3 pool. App-only and App+Browser are
separately evaluated configurations, not an automatic fallback.
The memory card depicts a real retained positive predicate; its exact formula is in the SVG desc.
The App F + C1 U example is a logical example backed by runtime tests, not a new measurement.
The decision order is EMPTY_MODEL, relevant FAILED, any T -> ALERT, all F -> NO ALERT,
otherwise UNKNOWN. Missing unselected fields do not fail the detector.
NO ALERT does not certify authenticity. No intervention labels or recovery history feed runtime.

EVIDENCE USED
Current manuscript: hybridguard_latex_v4/input_markdown/sections/03_method.md and
04_evaluation_protocol.md; floats/figure_02.tex.
Implementation review: App candidate dependency catalog and saved retention models;
mtc_constrained_reselection.py and mtc_relation_selection.py; optional C1 test_runtime.py.
Only the figure package was authored; no code, data, results, or manuscript text was changed.
